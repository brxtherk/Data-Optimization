# -*- coding: utf-8 -*-
"""
Created on Tue May 20 09:48:35 2025

@author: jinuk
"""


#%%
#과제1-1

from ortools.linear_solver import pywraplp

nCity = 5

DIST = [[0,125,225,155,215],
        [125,0,85,115,135],
        [225,85,0,165,190],
        [155,115,165,0,195],
        [215,135,190,195,0],
        ]

solver = pywraplp.Solver.CreateSolver("SAT")

X = {}
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            X[i, j] = solver.IntVar(0, 1, "X"+str(i)+str(j))
  
U = {}
for i in range(1, nCity):
    U[i] = solver.IntVar(1, nCity-1, "U[%i]" %i)
    
# 제약조건
# 도시j로한번은들어와야한다.
for j in range(nCity):
    solver.Add(solver.Sum([X[i,j] for i in range(nCity) if i != j]) == 1)

# 도시j로부터한번은나와야한다.
for i in range(nCity):
    solver.Add(solver.Sum([X[i,j] for j in range(nCity) if i != j]) == 1)

# 방문순서제약
for i in range(1, nCity):
    for j in range(1, nCity):
        if i != j:
            solver.Add(U[i]-U[j] + 1 - (nCity-1)*(1-X[i, j]) <= 0)
            

# Objective
objective_terms = []
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            objective_terms.append(DIST[i][j] * X[i, j])

solver.Minimize(solver.Sum(objective_terms))

if 1:
    with open('or9-1.lp', "w") as out_f:
        lp_text = solver.ExportModelAsLpFormat(False)
        out_f.write(lp_text)

# Solve
status = solver.Solve()

# Print solution.
if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE:
    print(f"Total dist = {solver.Objective().Value():.1f}\n", )
    for i in range(nCity):
        for j in range(nCity):
            if i != j:
                if X[i, j].solution_value() > 0.5:
                    print(f"X{i} --> X{j}")
    for i in range(1, nCity):
        print(f"{i} 도시 방문순서: ", U[i].solution_value())
else:
    print("No solution found.")
    
#%%
#과제1-2

from ortools.constraint_solver import routing_enums_pb2
from ortools.constraint_solver import pywrapcp

def create_data_model():
    data = {}
    data["distance_matrix"] = [
    [0, 125,225,155,215],
    [125, 0,85,115,135],
    [225, 85, 0,165,190],
    [155,115,165, 0, 195],
    [215,135,190,195,0]
    ]
    
    data["num_vehicles"] = 1
    data["depot"] = 0
    return data

data = create_data_model()

# 색인 관리자, 일종의 정보관리자
manager = pywrapcp.RoutingIndexManager(len(data["distance_matrix"]), data["num_vehicles"], data["depot"])

# Routing 객체 생성
routing = pywrapcp.RoutingModel(manager)

# 두 점 사이의 거리를 반환한다.
def distance_callback(from_index, to_index):
    from_node = manager.IndexToNode(from_index)
    to_node = manager.IndexToNode(to_index)
    return data["distance_matrix"][from_node][to_node]

# 거리 계산 함수를 callback 함수로 등록하고 활용함.
transit_callback_index = routing.RegisterTransitCallback(distance_callback)
routing.SetArcCostEvaluatorOfAllVehicles(transit_callback_index)

# 시작해를 찾기 위한 휴리스틱 메소드를 등록
search_parameters = pywrapcp.DefaultRoutingSearchParameters()
search_parameters.first_solution_strategy = (routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC)

def print_solution(manager, routing, solution):
    print(f"Objective: {solution.ObjectiveValue()} miles")
    index = routing.Start(0)
    plan_output = "Route for vehicle 0:\n"
    route_distance = 0
    while not routing.IsEnd(index):
        plan_output += f" {manager.IndexToNode(index)} ->"
        previous_index = index
        index = solution.Value(routing.NextVar(index))
        route_distance += routing.GetArcCostForVehicle(previous_index, index, 0)
    plan_output += f" {manager.IndexToNode(index)}\n"
    print(plan_output)
    plan_output += f"Route distance: {route_distance}miles\n"


# 문제 풀이
solution = routing.SolveWithParameters(search_parameters)
if solution:
    print_solution(manager, routing, solution)

# 해 경로를 리스트에 저장하기 (Optional)
def get_routes(solution, routing, manager):
    routes = []
    for route_nbr in range(routing.vehicles()):
        index = routing.Start(route_nbr)
        route = [manager.IndexToNode(index)]
        while not routing.IsEnd(index):
            index = solution.Value(routing.NextVar(index))
            route.append(manager.IndexToNode(index))
        routes.append(route)
    return routes

routes = get_routes(solution, routing, manager)

# Display the routes.
for i, route in enumerate(routes):
    print('Route', i, route)
    
#%%
# 과제 1-3: Nearest Neighbor Algorithm

import numpy as np

# 거리 행렬
DIST = [
    [0, 125, 225, 155, 215],
    [125, 0, 85, 115, 135],
    [225, 85, 0, 165, 190],
    [155, 115, 165, 0, 195],
    [215, 135, 190, 195, 0]
]

nCity = len(DIST)
visited = [False] * nCity
route = []

# 시작 도시는 0
current_city = 0
visited[current_city] = True
route.append(current_city)
total_distance = 0

for _ in range(nCity - 1):
    nearest_city = -1
    min_distance = float('inf')
    
    for next_city in range(nCity):
        if not visited[next_city] and DIST[current_city][next_city] < min_distance:
            min_distance = DIST[current_city][next_city]
            nearest_city = next_city

    visited[nearest_city] = True
    route.append(nearest_city)
    total_distance += DIST[current_city][nearest_city]
    current_city = nearest_city

# 마지막 도시에서 출발 도시(0)로 돌아감
route.append(0)
total_distance += DIST[current_city][0]

# 출력
print(" Nearest Neighbor 경로:", ' → '.join(map(str, route)))
print("총 거리:", total_distance)


#0 -> 1 -> 2 -> 3 -> 4

#최소가 아님.

#%%
#과제2-1

from ortools.linear_solver import pywraplp

nCity = 9

DIST = [[0,20,30,25,12,33,44,57,0],
        [22,0,19,20,20,29,43,45,0],
        [28,19,0,17,38,48,55,60,0],
        [25,20,19,0,28,35,40,55,0],
        [12,18,34,25,0,21,30,40,0],
        [35,25,45,30,20,0,25,39,0],
        [47,39,50,35,28,20,0,28,0],
        [60,38,54,50,33,40,25,0,0],
        [0,0,0,0,0,0,0,0,0]
        ]

solver = pywraplp.Solver.CreateSolver("SAT")

X = {}
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            X[i, j] = solver.IntVar(0, 1, "X"+str(i)+str(j))
  
U = {}
for i in range(1, nCity):
    U[i] = solver.IntVar(1, nCity-1, "U[%i]" %i)
    
# 제약조건
# 도시j로한번은들어와야한다.
for j in range(nCity):
    solver.Add(solver.Sum([X[i,j] for i in range(nCity) if i != j]) == 1)

# 도시j로부터한번은나와야한다.
for i in range(nCity):
    solver.Add(solver.Sum([X[i,j] for j in range(nCity) if i != j]) == 1)

# 방문순서제약
for i in range(1, nCity):
    for j in range(1, nCity):
        if i != j:
            solver.Add(U[i]-U[j] + 1 - (nCity-1)*(1-X[i, j]) <= 0)

# Objective
objective_terms = []
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            objective_terms.append(DIST[i][j] * X[i, j])

solver.Minimize(solver.Sum(objective_terms))

if 1:
    with open('or9-1.lp', "w") as out_f:
        lp_text = solver.ExportModelAsLpFormat(False)
        out_f.write(lp_text)

# Solve
status = solver.Solve()

# Print solution.
if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE:
    print(f"Total cost = {solver.Objective().Value():.1f}\n", )
    for i in range(nCity):
        for j in range(nCity):
            if i != j:
                if X[i, j].solution_value() > 0.5:
                    print(f"X{i} --> X{j}")
    for i in range(1, nCity):
        print(f"{i} 도시 방문순서: ", U[i].solution_value())
else:
    print("No solution found.")
    
#가능하다

#%%
#과제2-2

from ortools.linear_solver import pywraplp

nCity = 9

DIST = [[0,20,30,25,12,33,44,57,0],
        [22,0,19,20,20,29,43,45,0],
        [28,19,0,17,38,48,55,60,0],
        [25,20,19,0,28,35,40,55,0],
        [12,18,34,25,0,21,30,40,0],
        [35,25,45,30,20,0,25,39,0],
        [47,39,50,35,28,20,0,28,0],
        [60,38,54,50,33,40,25,0,0],
        [0,0,0,0,0,0,0,0,0]
        ]

solver = pywraplp.Solver.CreateSolver("SAT")

X = {}
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            X[i, j] = solver.IntVar(0, 1, "X"+str(i)+str(j))
  
U = {}
for i in range(1, nCity):
    U[i] = solver.IntVar(1, nCity-1, "U[%i]" %i)
    
# 제약조건
# 도시j로한번은들어와야한다.
for j in range(nCity):
    solver.Add(solver.Sum([X[i,j] for i in range(nCity) if i != j]) == 1)

# 도시j로부터한번은나와야한다.
for i in range(nCity):
    solver.Add(solver.Sum([X[i,j] for j in range(nCity) if i != j]) == 1)

# 방문순서제약
for i in range(1, nCity):
    for j in range(1, nCity):
        if i != j:
            solver.Add(U[i]-U[j] + 1 - (nCity-1)*(1-X[i, j]) <= 0)

solver.Add(X[5,8]  == 1)

# Objective
objective_terms = []
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            objective_terms.append(DIST[i][j] * X[i, j])

solver.Minimize(solver.Sum(objective_terms))

if 1:
    with open('or9-1.lp', "w") as out_f:
        lp_text = solver.ExportModelAsLpFormat(False)
        out_f.write(lp_text)

# Solve
status = solver.Solve()

# Print solution.
if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE:
    print(f"Total cost = {solver.Objective().Value():.1f}\n", )
    for i in range(nCity):
        for j in range(nCity):
            if i != j:
                if X[i, j].solution_value() > 0.5:
                    print(f"X{i} --> X{j}")
    for i in range(1, nCity):
        print(f"{i} 도시 방문순서: ", U[i].solution_value())
else:
    print("No solution found.")
    
#153달러

#%%
#과제3-1
from ortools.linear_solver import pywraplp

DIST = [
    [0, 20, 15, 19, 24, 14, 21, 11],
    [20, 0, 18, 22, 23, 22, 9, 10],
    [15, 18, 0, 11, 21, 14, 32, 12],
    [19, 22, 11, 0, 20, 27, 18, 15],
    [24, 23, 21, 20, 0, 14, 25, 20], 
    [14, 22, 14, 27, 14, 0, 26, 17], 
    [21, 9, 32, 18, 25, 26, 0, 20],
    [11, 10, 12, 15, 20, 17, 20, 0]
]

nCity = len(DIST)
solver = pywraplp.Solver.CreateSolver("CBC")

# 경로 선택 변수 X[i,j]: 도시 i에서 j로 가는 경로 여부
X = {}
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            X[i, j] = solver.IntVar(0, 1, f"X[{i},{j}]")

# 방문 순서 변수 U[i]
U = {}
for i in range(1, nCity):
    U[i] = solver.NumVar(1, nCity - 1, f"U{i}")

# 제약조건
# 각 도시는 한 번만 들어오고
for j in range(nCity):
    solver.Add(solver.Sum([X[i, j] for i in range(nCity) if i != j]) == 1)

# 각 도시는 한 번만 나가야 함
for i in range(nCity):
    solver.Add(solver.Sum([X[i, j] for j in range(nCity) if i != j]) == 1)

# Subtour 제거 (MTZ 방식)
for i in range(1, nCity):
    for j in range(1, nCity):
        if i != j:
            solver.Add(U[i] - U[j] + nCity * X[i, j] <= nCity - 1)

# 추가 조건: 도시 1은 도시 5보다 같거나 나중에 방문
solver.Add(U[1] >= U[5])

# 목적 함수: 총 거리 최소화
objective_terms = []
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            objective_terms.append(DIST[i][j] * X[i, j])
solver.Minimize(solver.Sum(objective_terms))

# 풀이
status = solver.Solve()

# 결과 출력
if status == pywraplp.Solver.OPTIMAL:
    print(f"총 최소 거리: {solver.Objective().Value():.1f}")
    print("방문 경로:")
    for i in range(nCity):
        for j in range(nCity):
            if i != j and X[i, j].solution_value() > 0.5:
                print(f"{i} → {j}")
    
    print("\n도시별 방문 순서:")
    for i in range(1, nCity):
        print(f"도시 {i}: 순서 {round(U[i].solution_value())}")
else:
    print("최적해를 찾을 수 없습니다.")

    
#%%과제3-2
from ortools.linear_solver import pywraplp

nCity = 8

Time = [[0,20,15,19,24,14,21,11],
        [20,0,18,22,23,22,9,10],
        [15,18,0,11,21,14,32,12],
        [19,22,11,0,20,27,18,15],
        [24,23,21,20,0,14,25,20],
        [14,22,14,27,14,0,26,17],
        [21,9,32,18,25,26,0,20],
        [11,10,12,15,20,17,20,0]
        ]

solver = pywraplp.Solver.CreateSolver("CBC")

X = {}
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            X[i, j] = solver.IntVar(0, 1, f"X[{i},{j}]")

U = {}
for i in range(1, nCity):
    U[i] = solver.NumVar(1, nCity - 1, f"U{i}")

# 각 고객은 한 번만 들어오고
for j in range(nCity):
    solver.Add(solver.Sum([X[i, j] for i in range(nCity) if i != j]) == 1)

# 각 고객은 한 번만 나간다
for i in range(nCity):
    solver.Add(solver.Sum([X[i, j] for j in range(nCity) if i != j]) == 1)

# Subtour 제거 (MTZ 방식)
for i in range(1, nCity):
    for j in range(1, nCity):
        if i != j:
            solver.Add(U[i] - U[j] + nCity * X[i, j] <= nCity - 1)

# 고객 2, 3은 가장 먼저 방문
for i in range(1, nCity):
    if i not in [2, 3]:
        solver.Add(U[2] <= U[i] - 1)
        solver.Add(U[3] <= U[i] - 1)

# 고객 2 → 6 바로 이어서 방문
solver.Add(X[2, 6] == 1)
solver.Add(U[6] == U[2] + 1)

# 목적함수: 최소 시간
objective_terms = []
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            objective_terms.append(Time[i][j] * X[i, j])
solver.Minimize(solver.Sum(objective_terms))

# 풀이
status = solver.Solve()

if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE:
    print(f"총 최소 이동 시간: {solver.Objective().Value():.1f}")
    print("방문 경로:")
    for i in range(nCity):
        for j in range(nCity):
            if i != j and X[i, j].solution_value() > 0.5:
                print(f"{i} → {j}")
    print("\n고객별 방문 순서:")
    for i in range(1, nCity):
        print(f"고객 {i}: 순서 {round(U[i].solution_value())}")
else:
    print("최적해를 찾을 수 없습니다.")

#%%과제4-1
DIST = [
    [0, 4, 4, 3, 3, 3],
    [4, 0, 3, 4, 3, 4],
    [4, 3, 0, 4, 2, 2],
    [3, 4, 4, 0, 3, 3],
    [3, 3, 2, 3, 0, 3],
    [3, 4, 2, 3, 3, 0]
]
#%%과제4-2(1)

from ortools.linear_solver import pywraplp

Meeting = [
    [0, 4, 4, 3, 3, 3, 0],
    [4, 0, 3, 4, 3, 4, 0],
    [4, 3, 0, 4, 2, 2, 0],
    [3, 4, 4, 0, 3, 3, 0],
    [3, 3, 2, 3, 0, 3, 0],
    [3, 4, 2, 3, 3, 0, 0],
    [0, 0, 0 ,0 ,0 ,0 ,0]
    ]

nMeet = len(Meeting)

solver = pywraplp.Solver.CreateSolver("SAT")

X = {}
for i in range(nMeet):
    for j in range(nMeet):
        if i != j:
            X[i, j] = solver.IntVar(0, 1, "X"+str(i)+str(j))
  
U = {}
for i in range(1, nMeet):
    U[i] = solver.IntVar(1, nMeet-1, "U[%i]" %i)
    
    
# 제약조건
# 도시j로 한번은 들어와야 한다.
for j in range(nMeet):
    solver.Add(solver.Sum([X[i,j] for i in range(nMeet) if i != j]) == 1)

# 도시j로부터 한번은 나와야 한다.
for i in range(nMeet):
    solver.Add(solver.Sum([X[i,j] for j in range(nMeet) if i != j]) == 1)

# 방문 순서를 제약한다.
for i in range(1, nMeet):
    for j in range(1, nMeet):
        if i != j:
            solver.Add(U[i]-U[j] + 1 - (nMeet-1)*(1-X[i, j]) <= 0)

objective_terms = []
for i in range(nMeet):
    for j in range(nMeet):
        if i != j:
            objective_terms.append(Meeting[i][j] * X[i, j])

solver.Minimize(solver.Sum(objective_terms))

if 1:
    with open('or9-1.lp', "w") as out_f:
        lp_text = solver.ExportModelAsLpFormat(False)
        out_f.write(lp_text)

# Solve
status = solver.Solve()

# Print solution.
if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE:
    print(f"Total = {solver.Objective().Value():.1f}\n", )
    for i in range(nMeet):
        for j in range(nMeet):
            if i != j:
                if X[i, j].solution_value() > 0.5:
                    print(f"X{i} --> X{j}")
    for i in range(1, nMeet):
        print(f"{i} 회의 순서: ", U[i].solution_value())
else:
    print("No solution found.")

#%%4-2(2)
from ortools.linear_solver import pywraplp
import pandas as pd

# 회의 간 거리 행렬 (직원 이동 수 기반)
DIST = [
    [0, 4, 4, 6, 6, 5, 0],
    [4, 0, 6, 4, 6, 3, 0],
    [4, 6, 0, 4, 6, 6, 0],
    [6, 4, 4, 0, 6, 5, 0],
    [6, 6, 6, 6, 0, 5, 0],
    [5, 3, 6, 5, 6, 0, 0],
    [0, 0, 0, 0, 0, 0, 0]
]

nCity = len(DIST)
solver = pywraplp.Solver.CreateSolver("SAT")

# 경로 선택 변수 X[i,j]
X = {}
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            X[i, j] = solver.IntVar(0, 1, f"X[{i},{j}]")

# 순서 변수 U[i] (MTZ 방식)
U = {}
for i in range(1, nCity):
    U[i] = solver.NumVar(1, nCity - 1, f"U{i}")

# 제약조건
# 각 회의는 한 번 들어오고
for j in range(nCity):
    solver.Add(solver.Sum([X[i, j] for i in range(nCity) if i != j]) == 1)

# 각 회의는 한 번 나가야 함
for i in range(nCity):
    solver.Add(solver.Sum([X[i, j] for j in range(nCity) if i != j]) == 1)

# 순회 방지 (MTZ 방식)
for i in range(1, nCity):
    for j in range(1, nCity):
        if i != j:
            solver.Add(U[i] - U[j] + nCity * X[i, j] <= nCity - 1)

# 목적 함수: 총 이동 인원 수 최소화
objective_terms = []
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            objective_terms.append(DIST[i][j] * X[i, j])

solver.Minimize(solver.Sum(objective_terms))

# LP 형식으로 저장 (선택)
with open('hw4-4.lp', "w") as out_f:
    lp_text = solver.ExportModelAsLpFormat(False)
    out_f.write(lp_text)

# 문제 풀이
status = solver.Solve()

# 결과 출력
if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE:
    print(f"총 최소 이동 수: {solver.Objective().Value():.1f}\n")
    for i in range(nCity):
        for j in range(nCity):
            if i != j and X[i, j].solution_value() > 0.5:
                print(f"회의 {i} → 회의 {j}")
    print("\n회의 순서:")
    for i in range(1, nCity):
        print(f"회의 {i}: 순서 {round(U[i].solution_value())}")
else:
    print(" 최적해를 찾을 수 없습니다.")
   
#%%과제5
from ortools.linear_solver import pywraplp
import pandas as pd

# 거리 행렬 (식사 배달 경로) + 가상 노드 포함
DIST = [
    [0, 10, 12, 5, 17, 9, 13, 7, 0],
    [10, 0, 9, 20, 8, 11, 3, 5, 0],
    [12, 9, 0, 14, 4, 10, 1, 16, 0],
    [5, 20, 14, 0, 20, 5, 28, 10, 0],
    [17, 8, 4, 20, 0, 21, 4, 9, 0],
    [9, 11, 10, 5, 21, 0, 2, 3, 0],
    [13, 3, 1, 28, 4, 2, 0, 2, 0],
    [7, 5, 16, 10, 9, 3, 2, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0]  # 가상 노드 (마지막 도착지)
]

nCity = len(DIST)
solver = pywraplp.Solver.CreateSolver("SAT")

# 경로 변수 X[i,j]
X = {}
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            X[i, j] = solver.IntVar(0, 1, f"X[{i},{j}]")

# 방문 순서 변수 U[i]
U = {}
for i in range(1, nCity):
    U[i] = solver.NumVar(1, nCity - 1, f"U{i}")

# 제약조건
# 각 도시(식사 배달지)는 한 번 들어오고
for j in range(nCity - 1):  # 마지막 노드는 제외
    solver.Add(solver.Sum([X[i, j] for i in range(nCity) if i != j]) == 1)

# 각 도시에서는 한 번만 나간다 (도착지 제외)
for i in range(nCity - 1):
    solver.Add(solver.Sum([X[i, j] for j in range(nCity) if i != j]) == 1)

# 마지막 노드는 들어오기만 허용 (Open Tour)
solver.Add(solver.Sum([X[i, nCity - 1] for i in range(nCity - 1)]) == 1)
for j in range(nCity):
    if j != nCity - 1:
        solver.Add(X[nCity - 1, j] == 0)

# Subtour 제거 (MTZ 방식)
for i in range(1, nCity - 1):
    for j in range(1, nCity - 1):
        if i != j:
            solver.Add(U[i] - U[j] + nCity * X[i, j] <= nCity - 1)

# 목적 함수: 총 이동 거리 최소화
objective_terms = []
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            objective_terms.append(DIST[i][j] * X[i, j])

solver.Minimize(solver.Sum(objective_terms))

# 문제 저장 (선택)
with open('hw5-meal.lp', "w") as out_f:
    lp_text = solver.ExportModelAsLpFormat(False)
    out_f.write(lp_text)

# 문제 풀이
status = solver.Solve()

# 결과 출력
if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE:
    print(f"총 최소 이동 거리: {solver.Objective().Value():.1f}")
    print("배달 경로:")
    for i in range(nCity):
        for j in range(nCity):
            if i != j and X[i, j].solution_value() > 0.5:
                print(f"{i} → {j}")
    print("\n도시별 방문 순서:")
    for i in range(1, nCity - 1):
        print(f"도시 {i}: 순서 {round(U[i].solution_value())}")
else:
    print("최적해를 찾을 수 없습니다.")
