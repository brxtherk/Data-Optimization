# -*- coding: utf-8 -*-
"""
Created on Tue May 27 14:06:20 2025

@author: jinuk
"""
#%% 1번
from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver('SCIP')

cost=[[23,9,23,29,33],
      [19,15,21,26,36],
      [31,11,40,40,20]]

need=[15000,40000,13000,12000,19000]

low_cost=[18000000,17500000,24500000]
high_cost=[23400000,22750000,31850000]

low=40000
high=60000

x={}
for i in range(3):
    for j in range(5):
        x[i,j]=solver.IntVar(0,solver.infinity(),f'{i+1} -> {j+1} 생산량')
y={}
for i in range(3):
   y[i]=solver.IntVar(0,1,f'{i+1}지역에 저용량 공장')
z={}

for i in range(3):
   z[i]=solver.IntVar(0,1,f'{i+1}지역에 고용량 공장')

for i in range(3):
        solver.Add(sum(x[i,j] for j in range(5))<=low*y[i]+high*z[i])
        solver.Add(y[i]+z[i]==1)
        
for j in range(5):
    solver.Add(sum(x[i,j] for i in range(3))>=need[j])

solver.Minimize(sum(cost[i][j]*x[i,j] for i in range(3) for j in range(5))+
                sum(low_cost[i]*y[i]+high_cost[i]*z[i] for i in range(3)))

status=solver.Solve()
if status==pywraplp.Solver.OPTIMAL:
    print(f'총비용 : {solver.Objective().Value()}')
    for i in range(3):
        if y[i].solution_value()>0.3:
            print(y[i].name())
        if z[i].solution_value()>0.3:
            print(z[i].name())
        for j in range(5):
            if x[i,j].solution_value()>0.3:
                print(f'{x[i,j].name()}: {x[i,j].solution_value()}')
#%% 2번
from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver('SCIP')

dist=[[0,125,225,155,215],
      [125,0,85,115,135],
      [225,85,0,165,190],
      [155,115,165,0,195],
      [215,135,190,195,0]]

name=['Basin','Wald','Bon','Mena','Kiln']

x={}
u={}
for i in range(5):
    for j in range(5):
        if i!=j:
            x[i,j]=solver.IntVar(0,1,f'{name[i]}->{name[j]}')

for i in range(1,5):
    u[i]=solver.IntVar(1,4,'방문도시순서')

for i in range(5):
    solver.Add(sum(x[i,j] for j in range(5) if i!=j)==1)
    solver.Add(sum(x[j,i] for j in range(5) if i!=j)==1)

for i in range(1,5):
    for j in range(1,5):
        if i!=j:
            solver.Add(u[i]+5*x[i,j]<=u[j]+4)
        

solver.Minimize(sum(dist[i][j]*x[i,j] for i in range(5) for j in range(5) if i!=j))

status=solver.Solve()
if status==pywraplp.Solver.OPTIMAL:
    print(f'총거리 : {solver.Objective().Value()}')
    for i in range(5):
        for j in range(5):
            if i!=j:
                if x[i,j].solution_value()>0.3:
                    print(x[i,j].name())
#%% 3번

from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver('SCIP')

A={(0,1):4.6,(0,2):4.7,(0,3):4.2,
   (1,4):3.5,(1,5):3.4,
   (2,4):3.6,(2,5):3.2,(2,6):3.3,
   (3,5):3.5,(3,6):3.4,
   (4,7):3.4,(5,7):3.6,(6,7):3.8}



flow=[1,0,0,0,0,0,0,-1]

name=['인천','a','b','c','d','e','f','파리']

n=8

for key in A.keys():
    x[key]=solver.IntVar(0,1,'fds')

for i in range(n):
    exp=[]
    for (k,t) in A.keys():
        if k==i:
            exp.append(x[k,t])
        elif t==i:
            exp.append(-x[k,t])
    solver.Add(sum(exp)==flow[i])
flytime=[]
for (i,j),fly in A.items():
    flytime.append(x[i,j]*fly)

solver.Minimize(sum(flytime))
status=solver.Solve()
if status==pywraplp.Solver.OPTIMAL:
    print(f'총이동거리 : {solver.Objective().Value()}')
    for (i,j) in A.keys():
        if x[i,j].solution_value()>0.1:
            print(f'{name[i]}->{name[j]}')

#%% 4번

from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver('SCIP')

need=[2900,3900]
lim=[2100,1800,3000]
pro=[5,4,7]
on=[700,800,900]
setup=[3000,2000,1000]
P,I,S,Y={},{},{},{}

for i in range(3):
    for j in range(1,3):
        P[i,j]=solver.IntVar(0,solver.Infinity(),f'{i+1} 발전기의 {j}시간 발전량')
        S[i,j]=solver.IntVar(0,1,'셋업여부')
for i in range(3):
    for j in range(3):
        Y[i,j]=solver.IntVar(0,1,'켜져있는지')
for i in range(3):
    I[i]=solver.IntVar(0,solver.Infinity(),'{i}시간 발전량')

solver.Add(I[0]==0)
for i in range(3):
    solver.Add(Y[i,0]==0)

for i in range(1,3):
        solver.Add(I[i]==sum(P[j,i] for j in range(3)))

for i in range(1,3):
    solver.Add(I[i]==need[i-1])
    
for i in range(3):
    solver.Add(S[i,1]==Y[i,1])
    solver.Add(S[i,2]>=Y[i,2]-Y[i,1])

for i in range(3):
    for j in range(1,3):
        solver.Add(P[i,j]<=lim[i]*Y[i,j])
        solver.Add(P[i,j]>=Y[i,j])

solver.Minimize(sum(P[i,j]*pro[i] for i in range(3) for j in range(1,3))+
                sum(Y[i,j]*on[i] for i in range(3) for j in range(1,3))+
                sum(S[i,j]*setup[i] for i in range(3) for j in range(1,3)))

status=solver.Solve()
if status==pywraplp.Solver.OPTIMAL:
    print(f'총비용 : {solver.Objective().Value()}')
    for i in range(3):
        for j in range(1,3):
            if P[i,j].solution_value()>0.1:
                print(f'{P[i,j].name()} {P[i,j].solution_value()}')
#%% 5번

from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver('SCIP')

DAS=[[1,0,1,1,0],
     [1,1,1,0,1],
     [0,0,1,1,0],
     [0,1,1,1,0],
     [1,1,0,1,1],
     [1,0,0,1,0],
     [1,0,0,0,1]]
#상품선택
K=1

x,y={},{}

for i in range(5):
    x[i]=solver.IntVar(0,1,f'상품{i+1} 선택')

for i in range(7):
    y[i]=solver.IntVar(0,1,f'주문 100{i+1} 충족')

solver.Add(sum(x[i] for i in range(5))==K)

for i in range(7):
    solver.Add(sum(x[j] for j in range(5) if DAS[i][j]==1)>=
            sum(DAS[i])*y[i])

solver.Maximize(sum(y[i] for i in range(7)))

status=solver.Solve()
if status==pywraplp.Solver.OPTIMAL:
    print(f'만족된 주문수 : {solver.Objective().Value()}')
    for i in range(5):
        if x[i].solution_value()>0.1:
            print(x[i].name())
    for i in range(7):
        if y[i].solution_value()>0.1:
            print(y[i].name())
#%% 6번 
from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver('SCIP')

SMP=[5,5,5,5,5,5,10,10,10,10,15,15,15,15,15,15,10,10,10,10,5,5,5,5]
RPV=[0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,0,0,0,0]
FPV1=[0,0,0,0,0,0, 0.4, 0.8, 1.4, 2.2, 2.8, 3.0, 2.8, 2.6, 2.2, 1.6, 1.0, 0.4, 0.2, 0,0,0,0,0]
FPV2=[0,0,0,0,0,0, 0.5,1.0,1.8,2.0,2.5,3.5,2.3,2.2,2.1,1.3,1.0,0.5,0.1,0,0,0,0,0]

BIGM=10000
nTimes=24
infinity=solver.infinity
X={}
QCPV,QDPV={},{}
ESS={}
Y1,Y2={},{}
W={}
Z1,Z2={}

for j in range(2):
    for i in range(nTimes):
        Y1[j,i]==solver.IntVar(0,1,f'Y1{j}{i}')
        Y2[j,i]==solver.IntVar(0,1,f'Y2{j}{i}')
        W[j,i]==solver.NumVar(0,infinity,f'Y{j}{i}')
        Z1[j,i]==solver.IntVar(0,1,f'Z1{j}{i}')
        Z2[j,i]==solver.IntVar(0,1,f'Z2{j}{i}')
        X[j,i]==solver.NumVar(0,infinity,f'X{j}{i}')
        QCPV[j,i]==solver.NumVar(0,10,f'QCPV{j}{i}')
        QDPV[j,i]==solver.NumVar(0,10,f'QDPV{j}{i}')
for i in range(nTimes+1):
    ESS=solver.NumVar(0,10,f'ESS[{i}]')


for i in range(nTimes):       
        solver.Add(sum(X[j,i] for j in range(2))<=FPV1[i]+FPV2[i]+ESS[i])
        solver.Add(ESS[i+1]==ESS[i]+sum(QCPV[j,i]-QDPV[j,i] for j in range(2)))
        solver.Add(sum(QCPV[i,j]))
        
        
        
        