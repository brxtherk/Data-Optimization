# -*- coding: utf-8 -*-
"""
Created on Tue Jun  3 10:59:50 2025

@author: jinuk
"""

from ortools.linear_solver import pywraplp

solver = pywraplp.Solver.CreateSolver("SCIP")

SMP = [5]*6 + [10]*4 + [15]*6 + [10]*4 + [5]*4
RPV = [0]*10 + [5]*6 + [0]*8
FPV = [0]*6 + [0.4, 0.8, 1.4, 2.2, 2.8, 3.0, 2.8, 2.6, 2.2, 1.6, 1.0, 0.4, 0.2] + [0]*5

BIGM = 10000
nTimes = 24
infinity = solver.infinity()

# i시간대 전력 판매량
X = {}
for i in range(nTimes):
    X[i] = solver.NumVar(0, infinity, f"X[{i}]")

# i시간대 충전량/방전량
QCPV, QDPV = {}, {}
for i in range(nTimes):
    QCPV[i] = solver.NumVar(0, 10, f"QCPV[{i}]")
    QDPV[i] = solver.NumVar(0, 10, f"QDPV[{i}]")

# i시간대 ESS 저장량
ESS = {}
for i in range(nTimes+1):
    ESS[i] = solver.NumVar(0, 10, f"ESS[{i}]")

# 이진 변수
Y1, Y2, Z1, Z2 = {}, {}, {}, {}
for i in range(nTimes):
    Y1[i] = solver.IntVar(0, 1, f"Y1[{i}]")  # 충전 여부
    Y2[i] = solver.IntVar(0, 1, f"Y2[{i}]")  # 방전 여부
    Z1[i] = solver.IntVar(0, 1, f"Z1[{i}]")  # 발전량-판매량 > 0 여부
    Z2[i] = solver.IntVar(0, 1, f"Z2[{i}]")  # 발전량-판매량 < 0 여부

# 제약조건

# 제약식 1: 판매는 발전량 + 저장량 이내로
for i in range(nTimes):
    solver.Add(X[i] <= FPV[i] + ESS[i], f'c1_{i}')

# 제약식 2: ESS 에너지 수지
for i in range(nTimes):
    solver.Add(ESS[i+1] == ESS[i] + QCPV[i] - QDPV[i], f'c2_{i}')

# 제약식 3: 충전 또는 방전 중 하나만 가능
for i in range(nTimes):
    solver.Add(QCPV[i] <= BIGM * Y1[i], f'c3_1_{i}')
    solver.Add(QDPV[i] <= BIGM * Y2[i], f'c3_2_{i}')
    solver.Add(Y1[i] + Y2[i] <= 1, f'c3_3_{i}')  # 동시에 둘 다 불가

# 제약식 4: QCPV = max(FPV - X, 0)
for i in range(nTimes):
    solver.Add(FPV[i] - X[i] <= QCPV[i], f'c4_1_{i}')
    solver.Add(QCPV[i] <= FPV[i] - X[i] + BIGM * Z1[i], f'c4_2_{i}')
    solver.Add(QCPV[i] <= BIGM * Z2[i], f'c4_3_{i}')
    solver.Add(Z1[i] + Z2[i] == 1, f'c4_4_{i}')

# 제약식 5: 판매량 중 발전량 초과분은 ESS 방전으로 충당
for i in range(nTimes):
    solver.Add(QDPV[i] >= X[i] - FPV[i], f'c5_{i}')

# 제약식 6: ESS 초기값 0
solver.Add(ESS[0] == 0, 'c6')

# 목적 함수: 판매수익 + REC 수익 최대화
solver.Maximize(solver.Sum([SMP[i] * X[i] + RPV[i] * QCPV[i] for i in range(nTimes)]))

# 모델 실행
status = solver.Solve()

# 결과 출력
if status == pywraplp.Solver.OPTIMAL:
    print(f"전력판매수익 = {solver.Objective().Value():.1f}")
    print("시간\t판매량(X)\t충전(QCPV)\t방전(QDPV)\tESS")
    for i in range(nTimes):
        print(f"{i:02d}\t{X[i].solution_value():.2f}\t\t{QCPV[i].solution_value():.2f}\t\t{QDPV[i].solution_value():.2f}\t\t{ESS[i].solution_value():.2f}")
    print(f"ESS(24) = {ESS[24].solution_value():.2f}")
else:
    print("해를 찾을 수 없습니다.")
#%% 연습문제
from ortools.linear_solver import pywraplp

solver = pywraplp.Solver.CreateSolver("SCIP")

SMP = [5]*6 + [10]*4 + [15]*6 + [10]*4 + [5]*4  # 판매단가
RWT = [0]*8 + [5]*4 + [0]*12                    # 풍력 REC
FWT = [1]*12 + [2]*12                           # 풍력 발전량

BIGM = 10000
nTimes = 24
# 연속 변수: 판매량, 충전량, 방전량, ESS 저장량
X = {}
QCWT = {}
QDWT = {}
ESS = {}

for i in range(nTimes):
    X[i] = solver.NumVar(0, solver.infinity(), f"X[{i}]")          # 판매량
    QCWT[i] = solver.NumVar(0, 10, f"QCWT[{i}]")                   # 충전량
    QDWT[i] = solver.NumVar(0, 10, f"QDWT[{i}]")                   # 방전량

# ESS는 nTimes+1개 필요 (시간 0~24)
for i in range(nTimes + 1):
    ESS[i] = solver.NumVar(0, 10, f"ESS[{i}]")

# 이진 변수: 충전여부, 방전여부, max 표현용
Y1 = {}
Y2 = {}
Z1 = {}
Z2 = {}

for i in range(nTimes):
    Y1[i] = solver.IntVar(0, 1, f"Y1[{i}]")  # 충전 여부
    Y2[i] = solver.IntVar(0, 1, f"Y2[{i}]")  # 방전 여부
    Z1[i] = solver.IntVar(0, 1, f"Z1[{i}]")  # max 계산용
    Z2[i] = solver.IntVar(0, 1, f"Z2[{i}]")  # max 계산용

# 제약조건
for i in range(nTimes):
    solver.Add(X[i] <= FWT[i] + ESS[i])  # 판매 가능량
    solver.Add(ESS[i+1] == ESS[i] + QCWT[i] - QDWT[i])  # ESS 누적
    solver.Add(QCWT[i] <= BIGM * Y1[i])
    solver.Add(QDWT[i] <= BIGM * Y2[i])
    solver.Add(Y1[i] + Y2[i] <= 1)
    solver.Add(FWT[i] - X[i] <= QCWT[i])
    solver.Add(QCWT[i] <= FWT[i] - X[i] + BIGM * Z1[i])
    solver.Add(QCWT[i] <= BIGM * Z2[i])
    solver.Add(Z1[i] + Z2[i] == 1)
    solver.Add(QDWT[i] >= X[i] - FWT[i])  # 부족분 방전

solver.Add(ESS[0] == 0)

solver.Maximize(solver.Sum(SMP[i] * X[i] + RWT[i] * QDWT[i] for i in range(nTimes)))
status = solver.Solve()

# 결과 출력
if status == pywraplp.Solver.OPTIMAL:
     print("시간\t판매량\t충전량\t방전량\tESS")
    for i in range(nTimes):
        print(f"{i+1:02d}\t{X[i].solution_value():.2f}\t{QCWT[i].solution_value():.2f}\t{QDWT[i].solution_value():.2f}\t{ESS[i+1].solution_value():.2f}")
else:
    print("해를 찾을 수 없습니다.")
