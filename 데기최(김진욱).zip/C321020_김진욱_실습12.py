# -*- coding: utf-8 -*-
"""
Created on Tue May 20 09:50:14 2025

@author: jinuk
"""

from ortools.linear_solver import pywraplp
import matplotlib.pyplot as plt

# 가변 전기 요금
UC = [0] + [5]*9 + [25]*7 + [5]*8  # 인덱스 1~24 사용
CAPA = [15, 14, 16, 10, 17, 16, 15, 18]  # 기계 0~7
SC = 100  # setup cost

solver = pywraplp.Solver.CreateSolver("SAT")

# 변수 선언
P, I, S, Y = {}, {}, {}, {}

# 생산량 변수 P[i,j]: 기계 i, 시간 j (1~24)
for i in range(8):
    for j in range(1, 25):
        P[i, j] = solver.NumVar(0, solver.infinity(), f"P[{i},{j}]")

# 재고량 변수 I[i,j]: 시간은 0~24
for i in range(8):
    for j in range(25):
        I[i, j] = solver.NumVar(0, solver.infinity(), f"I[{i},{j}]")

# 셋업 발생 여부 S[i,j]: 시간 1~24
for i in range(8):
    for j in range(1, 25):
        S[i, j] = solver.IntVar(0, 1, f"S[{i},{j}]")

# 기계 가동 여부 Y[i,j]: 시간 0~24
for i in range(8):
    for j in range(25):
        Y[i, j] = solver.IntVar(0, 1, f"Y[{i},{j}]")

# ======================== 제약조건 ========================

# 재고 흐름 제약: 기계 0~6
for i in range(7):
    for j in range(1, 25):
        solver.Add(I[i, j] == I[i, j - 1] + P[i, j] - P[i + 1, j])

# 기계 7의 재고 흐름
for j in range(1, 25):
    solver.Add(I[7, j] == I[7, j - 1] + P[7, j])

# 초기 재고
for i in range(7):
    solver.Add(I[i, 0] == 2 * CAPA[i + 1])
solver.Add(I[7, 0] == 0)

# 기말 재고
for i in range(7):
    solver.Add(I[i, 24] == 2 * CAPA[i + 1])
solver.Add(I[7, 24] == 240)  # 하루 총 생산량 고정

# 생산량은 재고보다 클 수 없음 (기계 1~7)
for i in range(1, 8):
    for j in range(1, 25):
        solver.Add(P[i, j] <= I[i - 1, j - 1])

# 생산 용량 제약 + 가동 여부 반영
for i in range(8):
    for j in range(1, 25):
        solver.Add(P[i, j] <= CAPA[i] * Y[i, j])
        solver.Add(P[i, j] >= Y[i, j])  # 생산량 0이면 Y도 0 되게 유도

# 준비비용 제약
for i in range(8):
    solver.Add(Y[i, 0] == 0)
    solver.Add(S[i, 1] == Y[i, 1])
    for j in range(2, 25):
        solver.Add(S[i, j] >= Y[i, j] - Y[i, j - 1])

# ======================== 목적함수 ========================

objective_terms = []
for i in range(8):
    for j in range(1, 25):
        objective_terms.append(UC[j] * P[i, j] + SC * S[i, j])

solver.Minimize(solver.Sum(objective_terms))

# ======================== 최적화 및 결과 출력 ========================

status = solver.Solve()

if status in [pywraplp.Solver.OPTIMAL, pywraplp.Solver.FEASIBLE]:
    print("✅ Total cost:", solver.Objective().Value())
    
    # 생산량 시각화
    p_data, i_data = [], []
    for i in range(8):
        p_data.append([P[i, j].solution_value() for j in range(1, 25)])
        i_data.append([I[i, j].solution_value() for j in range(25)])

    plt.figure(figsize=(16, 6))
    for i in range(8):
        plt.subplot(2, 4, i+1)
        plt.plot(p_data[i], label=f"P[{i}] 생산량")
        plt.plot(i_data[i][1:], label=f"I[{i}] 재고")
        plt.title(f"기계 {i}")
        plt.legend()
    plt.tight_layout()
    plt.show()
else:
    print("❌ 최적해를 찾을 수 없습니다.")
#%% 실습 5-1

from ortools.linear_solver import pywraplp
import matplotlib.pyplot as plt

# UC를 전부 10으로 설정
UC = [0] + [10]*24
CAPA = [15, 14, 16, 10, 17, 16, 15, 18]
SC = 100  # setup cost

solver = pywraplp.Solver.CreateSolver("SCIP")

# 변수 선언
P, I, S, Y = {}, {}, {}, {}

for i in range(8):
    for j in range(1, 25):
        P[i, j] = solver.NumVar(0, solver.infinity(), f"P[{i},{j}]")
        S[i, j] = solver.IntVar(0, 1, f"S[{i},{j}]")
    for j in range(25):
        I[i, j] = solver.NumVar(0, solver.infinity(), f"I[{i},{j}]")
        Y[i, j] = solver.IntVar(0, 1, f"Y[{i},{j}]")

# 제약조건: 재고 흐름
for i in range(7):
    for j in range(1, 25):
        solver.Add(I[i, j] == I[i, j - 1] + P[i, j] - P[i + 1, j])
for j in range(1, 25):
    solver.Add(I[7, j] == I[7, j - 1] + P[7, j])

# 초기 재고
for i in range(7):
    solver.Add(I[i, 0] == 2 * CAPA[i + 1])
solver.Add(I[7, 0] == 0)

# 기말 재고
for i in range(7):
    solver.Add(I[i, 24] == 2 * CAPA[i + 1])
solver.Add(I[7, 24] == 240)

# 생산 제약: 재고로부터
for i in range(1, 8):
    for j in range(1, 25):
        solver.Add(P[i, j] <= I[i - 1, j - 1])

# 생산 제약: 기계 용량 + 가동 여부
for i in range(8):
    for j in range(1, 25):
        solver.Add(P[i, j] <= CAPA[i] * Y[i, j])
        solver.Add(P[i, j] >= Y[i, j])

# 준비비용 제약
for i in range(8):
    solver.Add(Y[i, 0] == 0)
    solver.Add(S[i, 1] == Y[i, 1])
    for j in range(2, 25):
        solver.Add(S[i, j] >= Y[i, j] - Y[i, j - 1])

# 목적함수
objective_terms = []
for i in range(8):
    for j in range(1, 25):
        objective_terms.append(UC[j] * P[i, j] + SC * S[i, j])
solver.Minimize(solver.Sum(objective_terms))

# 최적화
status = solver.Solve()

if status in [pywraplp.Solver.OPTIMAL, pywraplp.Solver.FEASIBLE]:
    print(f"총 생산비용 (전기요금 + 셋업비용): {solver.Objective().Value():.1f}원")
    print("기계별 총 생산량:")
    for i in range(8):
        total_p = sum(P[i, j].solution_value() for j in range(1, 25))
        print(f"  기계 {i}: {total_p:.1f}개")
    print("\n준비비용 발생 시간:")
    for i in range(8):
        s_times = [j for j in range(1, 25) if S[i, j].solution_value() > 0.5]
        if s_times:
            print(f"  기계 {i}: 시간 {s_times}")
else:
    print("최적해를 찾지 못했습니다.")
#%% 5-1-2
from ortools.linear_solver import pywraplp

CAPA = [15, 14, 16, 10, 17, 16, 15, 18]
SC = 100

UC_dict = {
    "UC1": [0] + [5]*10 + [10]*2 + [15]*4 + [10]*4 + [5]*4,
    "UC2": [0] + [5]*10 + [20]*2 + [20]*4 + [10]*4 + [5]*4,
    "UC3": [0] + [5]*10 + [25]*2 + [25]*4 + [10]*4 + [5]*4,
}

results = {}

for label, UC in UC_dict.items():
    solver = pywraplp.Solver.CreateSolver("SCIP")
    P, I, S, Y = {}, {}, {}, {}

    for i in range(8):
        for j in range(1, 25):
            P[i, j] = solver.NumVar(0, solver.infinity(), "")
            S[i, j] = solver.IntVar(0, 1, "")
        for j in range(25):
            I[i, j] = solver.NumVar(0, solver.infinity(), "")
            Y[i, j] = solver.IntVar(0, 1, "")

    for i in range(7):
        for j in range(1, 25):
            solver.Add(I[i, j] == I[i, j - 1] + P[i, j] - P[i + 1, j])
    for j in range(1, 25):
        solver.Add(I[7, j] == I[7, j - 1] + P[7, j])

    for i in range(7):
        solver.Add(I[i, 0] == 2 * CAPA[i + 1])
    solver.Add(I[7, 0] == 0)
    for i in range(7):
        solver.Add(I[i, 24] == 2 * CAPA[i + 1])
    solver.Add(I[7, 24] == 240)

    for i in range(1, 8):
        for j in range(1, 25):
            solver.Add(P[i, j] <= I[i - 1, j - 1])
    for i in range(8):
        for j in range(1, 25):
            solver.Add(P[i, j] <= CAPA[i] * Y[i, j])
            solver.Add(P[i, j] >= Y[i, j])
    for i in range(8):
        solver.Add(Y[i, 0] == 0)
        solver.Add(S[i, 1] == Y[i, 1])
        for j in range(2, 25):
            solver.Add(S[i, j] >= Y[i, j] - Y[i, j - 1])

    objective_terms = []
    for i in range(8):
        for j in range(1, 25):
            objective_terms.append(UC[j] * P[i, j] + SC * S[i, j])
    solver.Minimize(solver.Sum(objective_terms))
    status = solver.Solve()

    if status in [pywraplp.Solver.OPTIMAL, pywraplp.Solver.FEASIBLE]:
        results[label] = round(solver.Objective().Value(), 1)
    else:
        results[label] = None

# 출력
for label, cost in results.items():
    if cost is not None:
        print(f"[{label}] 총 비용: {cost}원")
    else:
        print(f"[{label}] ❌ 최적해를 찾지 못함")
#%%5-1-3
from ortools.linear_solver import pywraplp

# 전기요금 설정 (원래대로)
UC = [0] + [5]*9 + [25]*7 + [5]*8
SC = 100

# 기계 용량 수정: 기계 3만 업그레이드 (10 → 16)
CAPA = [15, 14, 16, 16, 17, 16, 15, 18]

solver = pywraplp.Solver.CreateSolver("SCIP")
P, I, S, Y = {}, {}, {}, {}

for i in range(8):
    for j in range(1, 25):
        P[i, j] = solver.NumVar(0, solver.infinity(), "")
        S[i, j] = solver.IntVar(0, 1, "")
    for j in range(25):
        I[i, j] = solver.NumVar(0, solver.infinity(), "")
        Y[i, j] = solver.IntVar(0, 1, "")

for i in range(7):
    for j in range(1, 25):
        solver.Add(I[i, j] == I[i, j - 1] + P[i, j] - P[i + 1, j])
for j in range(1, 25):
    solver.Add(I[7, j] == I[7, j - 1] + P[7, j])

for i in range(7):
    solver.Add(I[i, 0] == 2 * CAPA[i + 1])
    solver.Add(I[i, 24] == 2 * CAPA[i + 1])
solver.Add(I[7, 0] == 0)
solver.Add(I[7, 24] == 240)

for i in range(1, 8):
    for j in range(1, 25):
        solver.Add(P[i, j] <= I[i - 1, j - 1])
for i in range(8):
    for j in range(1, 25):
        solver.Add(P[i, j] <= CAPA[i] * Y[i, j])
        solver.Add(P[i, j] >= Y[i, j])

for i in range(8):
    solver.Add(Y[i, 0] == 0)
    solver.Add(S[i, 1] == Y[i, 1])
    for j in range(2, 25):
        solver.Add(S[i, j] >= Y[i, j] - Y[i, j - 1])

objective_terms = []
for i in range(8):
    for j in range(1, 25):
        objective_terms.append(UC[j] * P[i, j] + SC * S[i, j])
solver.Minimize(solver.Sum(objective_terms))

status = solver.Solve()

if status in [pywraplp.Solver.OPTIMAL, pywraplp.Solver.FEASIBLE]:
    print(f"[기계 3 업그레이드] 총 생산비용: {round(solver.Objective().Value(), 1)}원")
else:
    print("❌ 최적해를 찾지 못했습니다.")
#%% 5-2
from ortools.linear_solver import pywraplp

solver = pywraplp.Solver.CreateSolver("SCIP")

processes = {
    "A1": {"idx": 0, "capa": 12},
    "A2": {"idx": 1, "capa": 8},
    "B1": {"idx": 2, "capa": 15},
    "B2": {"idx": 3, "capa": 5},
    "C":  {"idx": 4, "capa": 15}
}

UC = [0] + [5]*6 + [10]*4 + [15]*3 + [25]*3 + [15]*3 + [10]*3 + [5]*2
SC = 100

P, I, Y, S = {}, {}, {}, {}
for p in processes:
    i = processes[p]["idx"]
    P[i], I[i], Y[i], S[i] = {}, {}, {}, {}
    for j in range(1, 25):
        P[i][j] = solver.NumVar(0, solver.infinity(), "")
        S[i][j] = solver.IntVar(0, 1, "")
    for j in range(25):
        I[i][j] = solver.NumVar(0, solver.infinity(), "")
        Y[i][j] = solver.IntVar(0, 1, "")

def add_flow(prev, nxt):
    i, k = processes[prev]["idx"], processes[nxt]["idx"]
    for j in range(1, 25):
        solver.Add(I[i][j] == I[i][j - 1] + P[i][j] - P[k][j])

add_flow("A1", "A2")
add_flow("A2", "C")
add_flow("B1", "B2")
add_flow("B2", "C")
for j in range(1, 25):
    solver.Add(I[processes["C"]["idx"]][j] == I[processes["C"]["idx"]][j - 1] + P[processes["C"]["idx"]][j])

for p in processes:
    i = processes[p]["idx"]
    if p in ["A1", "B1"]:
        solver.Add(I[i][0] == 0)
        solver.Add(I[i][24] == 0)
    elif p in ["A2", "B2"]:
        solver.Add(I[i][0] == 2 * processes["C"]["capa"])
        solver.Add(I[i][24] == 2 * processes["C"]["capa"])
    elif p == "C":
        solver.Add(I[i][0] == 0)
        solver.Add(I[i][24] == 100)

for p in processes:
    i = processes[p]["idx"]
    capa = processes[p]["capa"]
    for j in range(1, 25):
        if p not in ["A1", "B1"]:
            solver.Add(P[i][j] <= I[i - 1][j - 1])
        solver.Add(P[i][j] <= capa * Y[i][j])
        solver.Add(P[i][j] >= Y[i][j])

    solver.Add(Y[i][0] == 0)
    solver.Add(S[i][1] == Y[i][1])
    for j in range(2, 25):
        solver.Add(S[i][j] >= Y[i][j] - Y[i][j - 1])

objective_terms = []
for p in processes:
    i = processes[p]["idx"]
    for j in range(1, 25):
        objective_terms.append(UC[j] * P[i][j] + SC * S[i][j])
solver.Minimize(solver.Sum(objective_terms))

status = solver.Solve()

if status in [pywraplp.Solver.OPTIMAL, pywraplp.Solver.FEASIBLE]:
    print(f"총 생산비용: {round(solver.Objective().Value(), 1)}원")
else:
    print("❌ 최적해를 찾지 못했습니다.")

