# -*- coding: utf-8 -*-
"""
Created on Tue May 27 10:25:42 2025

@author: jinuk
"""
#%% 실습 1
import pandas as pd
import numpy as np

# 1. 파일 읽기 (파일 경로 맞춰줘야 함)
df = pd.read_excel(r'C:\Users\jinuk\OneDrive\바탕 화면\ddtt\ex1.xlsx', index_col='Unnamed: 0')

# 2. 고객과 상품 목록
cList = sorted(set(df['주문번호']))
pList = sorted(set(df['상품코드']))

# 3. 사용자-상품 행렬 생성 (수량 기준)
CP_MAT = pd.DataFrame(0, index=cList, columns=pList, dtype=int)
for i in range(df.shape[0]):
    CP_MAT.loc[df['주문번호'][i], df['상품코드'][i]] = df['수량'][i]

# 4. 이진화 (구매 여부만)
CP_MAT_01 = (CP_MAT != 0).astype(int)

# 5. 코사인 유사도 계산 함수
def calSimilarity(v1, v2):
    dot = np.dot(v1, v2)
    norm1 = np.linalg.norm(v1)
    norm2 = np.linalg.norm(v2)
    return dot / (norm1 * norm2) if norm1 > 0 and norm2 > 0 else 0

# 6. 유사도 행렬 생성
SIMs = pd.DataFrame(0.0, index=cList, columns=cList)
for i in range(len(cList)):
    for j in range(len(cList)):
        if i != j:
            SIMs.iloc[i, j] = calSimilarity(CP_MAT_01.iloc[i], CP_MAT_01.iloc[j])

# 7. 가장 유사한 사용자 찾기
similarone = {}
for i in range(len(cList)):
    user = cList[i]
    similar_user = SIMs.loc[user].idxmax()
    similarone[user] = similar_user
    print(f'user {user} and {similar_user} are similar')

# 8. 추천
print("\n--- 추천 결과 ---")
for i in range(len(cList)):
    user = cList[i]
    similar_user = similarone[user]
    for j in range(len(pList)):
        product = pList[j]
        if CP_MAT_01.loc[user, product] == 0 and CP_MAT_01.loc[similar_user, product] == 1:
            print(f'{product} for user {user}')
#%% 실습 2
import pandas as pd
import numpy as np
from ortools.linear_solver import pywraplp

# 1. 데이터 불러오기
ndf = pd.read_excel(r'C:\Users\jinuk\OneDrive\바탕 화면\ddtt\pr1.xlsx', header=0, index_col='Unnamed: 0')

# 2. 주문 및 제품 목록 추출
oList = sorted(set(ndf['주문번호']))
pList = sorted(set(ndf['상품코드']))
nOrders = len(oList)
nProducts = len(pList)
print(f"총 주문 수: {nOrders}, 총 제품 수: {nProducts}")

# 3. 주문-제품 매트릭스 생성 (수량 기반 → 구매 여부 0/1로 변환)
CP_MAT = pd.DataFrame(index=oList, columns=pList).fillna(0)
for i in range(ndf.shape[0]):
    CP_MAT.loc[ndf['주문번호'][i], ndf['상품코드'][i]] = ndf['수량'][i]

CP_MAT_01 = (CP_MAT != 0).astype(int)  # 이진화 매트릭스

# 4. OR-Tools Solver 설정
solver = pywraplp.Solver.CreateSolver("SAT")
BIGM = 1000000
K = 3  # 선택할 제품 수

# 5. 변수 선언
X = {}  # 제품 선택 여부
for j in range(nProducts):
    X[j] = solver.IntVar(0, 1, f"X[{j}]")

Y = {}  # 주문 미충족 여부
for i in range(nOrders):
    Y[i] = solver.IntVar(0, 1, f"Y[{i}]")

# 6. 제약조건: 각 주문에 대해 선택된 제품들로 충족 가능한지
for i in range(nOrders):
    need_count = int(CP_MAT_01.iloc[i].sum())  # 주문에 필요한 제품 수
    expr = solver.Sum([CP_MAT_01.iloc[i, j] * X[j] for j in range(nProducts)])
    solver.Add(expr + BIGM * Y[i] >= need_count)

# 7. 제약조건: 선택된 제품은 정확히 K개
solver.Add(solver.Sum([X[j] for j in range(nProducts)]) == K)

# 8. 목적함수: 미충족된 주문 수 최소화
solver.Minimize(solver.Sum([Y[i] for i in range(nOrders)]))

# 9. Solve
status = solver.Solve()

# 10. 결과 출력
if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE:
    fulfilled = int(nOrders - solver.Objective().Value())
    print(f"\n 총 충족된 주문 수: {fulfilled} / {nOrders}")

    print("\n 선택된 제품:")
    for j in range(nProducts):
        if X[j].solution_value() > 0.5:
            print(f" - 제품코드: {CP_MAT_01.columns[j]}")

else:
    print("❌ 최적 해를 찾지 못했습니다.")
#%% 실습 3
import pandas as pd
from ortools.linear_solver import pywraplp

# 1. pr1.xlsx 파일 불러오기
ndf = pd.read_excel(r'C:\Users\jinuk\OneDrive\바탕 화면\ddtt\pr1.xlsx', header=0, index_col='Unnamed: 0')

# 2. 주문, 제품 목록 정리
oList = sorted(set(ndf['주문번호']))
pList = sorted(set(ndf['상품코드']))
nOrders = len(oList)
nProducts = len(pList)

# 3. 주문-제품 수량 행렬 및 이진 행렬 생성
CP_MAT = pd.DataFrame(index=oList, columns=pList).fillna(0)
for i in range(ndf.shape[0]):
    CP_MAT.loc[ndf['주문번호'][i], ndf['상품코드'][i]] = ndf['수량'][i]

CP_MAT_01 = (CP_MAT != 0).astype(int)

# 4. OR-Tools 모델 구성
solver = pywraplp.Solver.CreateSolver("SAT")
BIGM = 1000000
K = 3  # 선택할 제품 수

# 5. 변수 선언
X = {j: solver.IntVar(0, 1, f"X[{j}]") for j in range(nProducts)}  # 제품 선택 여부
Y = {i: solver.IntVar(0, 1, f"Y[{i}]") for i in range(nOrders)}    # 주문 미충족 여부

# 6. 제약조건 추가
for i in range(nOrders):
    required = int(CP_MAT_01.iloc[i].sum())
    solver.Add(
        sum(CP_MAT_01.iloc[i, j] * X[j] for j in range(nProducts)) + BIGM * Y[i] >= required
    )

solver.Add(solver.Sum(X[j] for j in range(nProducts)) == K)

# 7. 목적함수: 미충족된 주문 수 최소화
solver.Minimize(solver.Sum(Y[i] for i in range(nOrders)))

# 8. 문제 해결
status = solver.Solve()

# 9. 결과 출력
if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE:
    fulfilled_orders = [CP_MAT_01.index[i] for i in range(nOrders) if Y[i].solution_value() < 0.1]
    selected_products = [CP_MAT_01.columns[j] for j in range(nProducts) if X[j].solution_value() > 0.5]

    print(f"\n✅ 총 충족된 주문 수: {len(fulfilled_orders)} / {nOrders}")
    print("\n📦 선택된 제품 코드:")
    for code in selected_products:
        print(" -", code)
else:
    print("❌ 최적 해를 찾지 못했습니다.")
