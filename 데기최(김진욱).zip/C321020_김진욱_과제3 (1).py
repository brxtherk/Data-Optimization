
from ortools.linear_solver import pywraplp

# solver 생성
solver = pywraplp.Solver.CreateSolver("SCIP")

#%%문제1-1
from ortools.linear_solver import pywraplp
solver=pywraplp.Solver.CreateSolver('SCIP')

x={}
for i in range(6):
    x[i]=solver.IntVar(0,1, f'x{i}')
    
solver.Add(6*x[0]+3*x[1]+5*x[2]+2*x[3]+4*x[4]+3*x[5]<=10)
solver.Add(x[2]+x[3]+x[5]<=1)
solver.Add(x[2]<=x[0])
solver.Add(x[3]<=x[1])
solver.Add(x[5]<=x[4])


solver.Maximize(9*x[0]+5*x[1]+6*x[2]+4*x[3]+7*x[4]+5*x[5])

status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print('목적함수값은?',solver.Objective().Value())
    for i in range(6):
        print(x[i].name(),x[i].solution_value())

#%%문제2
# 이익 데이터 (행: 슬롯 수 0~3, 열: 제품 1~3)
profits = [
    [0, 0, 0],   # 0 slots
    [1, 0, -1],  # 1 slot
    [3, 2, 2],   # 2 slots
    [3, 3, 4]    # 3 slots
]

# 변수 정의: x[i][j] = i개의 슬롯을 제품 j에 할당했는지 여부 (binary)
x = {}
for i in range(4):  # 슬롯 수 0~3
    for j in range(3):  # 제품 0~2
        x[(i, j)] = solver.IntVar(0, 1, f'x[{i}][{j}]')

# 제약조건 1: 각 제품에는 슬롯 수를 하나만 할당해야 함
for j in range(3):
    solver.Add(sum(x[(i, j)] for i in range(4)) == 1)

# 제약조건 2: 전체 사용한 슬롯 수는 정확히 5개여야 함
solver.Add(
    sum(i * x[(i, j)] for i in range(4) for j in range(3)) == 5
)

# 목적함수: 총 이익 최대화
objective = solver.Objective()
for i in range(4):
    for j in range(3):
        objective.SetCoefficient(x[(i, j)], profits[i][j])
objective.SetMaximization()

# 모델 풀기
status = solver.Solve()

# 결과 출력
if status == pywraplp.Solver.OPTIMAL:
    print("OPTIMAL")
    print("목적함수값 = ", solver.Objective().Value())
    for j in range(3):
        for i in range(4):
            if x[(i, j)].solution_value() > 0.5:
                print(f"제품 {j+1} → 광고 슬롯 {i}개 할당")
else:
    print("최적해를 찾을 수 없습니다.")
#%%문제3
infinity = solver.infinity()
a=[[1675, 400, 685, 1630, 1160, 2800],
   [1460, 1940, 970, 100, 495, 1200],
   [1925 ,2400 ,1425 ,500 ,950 ,800],
   [380 ,1355, 543, 1045 ,665 ,2321],
   [922 ,1646, 700 ,508 ,311 ,1797]]

need=[10,8,12,6,7,11]
pro=[18,24,27,22,31]
c=[7650,3500,3500,4100,2200]
M=1000000
x = {}
for i in range(5):
    for j in range(6):
        x[i, j] = solver.IntVar(0,infinity, f'x[{i}][{j}]')
y={}
for j in range(5):  
    y[j]=solver.IntVar(0,1,f'y[{j}]')

#제약조건1
for i in range(5):
    solver.Add(sum(x[i,j] for j in range(6))<=pro[i] )

#제약조건2
for i in range(5):
    solver.Add(sum(x[i,j] for j in range(6))<=M*y[i])

#제약조건3
for j in range(6):
    solver.Add(sum(x[i,j] for i in range(5))==need[j])
    
#목적함수
objective = solver.Objective()
for i in range(5):
    for j in range(6):
        objective.SetCoefficient(x[i, j], a[i][j])  # 수송 비용

for j in range(5):
    objective.SetCoefficient(y[j], c[j])            # 창고 고정비용

objective.SetMinimization()

# 모델 풀이
status = solver.Solve()

# 결과 출력
if status == pywraplp.Solver.OPTIMAL:
    print("OPTIMAL")
    print("목적함수값 = ", solver.Objective().Value())
    for i in range(5):
        for j in range(6):
            val = x[i, j].solution_value()
            if val > 0:
                print(f"창고 {i+1} → 도시 {j+1}: {val:.1f}톤")
else:
    print("최적해를 찾지 못했습니다.")