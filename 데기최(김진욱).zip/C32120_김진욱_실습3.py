# -*- coding: utf-8 -*-
"""
Created on Tue Mar 18 10:36:24 2025

@author: jinuk
"""
#%%실습1
#의사결정함수 : 각 기계 사용시간
#제약조건: 각기계사용시간이 50 이하, 제품수요의 최소조건
#목적함수:30(x00+x10+x20+x30)+50(x01+x11+x21+x31)+80(x02+x12+x22+x32)

from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver("SCIP")
p_names = ['Small', 'Medium', 'Large', 'ExLarge']
m_names = ['A', 'B', 'C']
o_costs = [30, 50, 80]
demands = [10000, 8000, 6000, 6000]
p_rates = [
[300, 600, 800],
[250, 400, 700],
[200, 350, 600],
[100, 200, 300]
]
infinity = solver.infinity()
# 의사결정 변수
# i = 0(Small), 1(Medium), 2(Large), 3(Ex Large), j = 0(A), 1(B), 2(C)
X = {}
for i in range(len(p_names)):
    for j in range(len(m_names)):
            X[i, j] = solver.NumVar(0, infinity, "X"+str(i)+str(j))

#생산 요구량
for i in range(len(p_names)):
    chae=[p_rates[i][j]*X[i,j] for j in range(len(m_names))]
    solver.Add(sum(chae)>=demands[i])

# 기계시간 제약
const_expr = []
for i in range(len(m_names)):
    const_expr = [X[j,i] for j in range(len(p_names))]
    solver.Add(sum(const_expr) <= 50, p_names[i]+'_capa')
    
# 목적함수
# 목적 함수 (운영 비용 최소화)
objective = solver.Objective()

for i in range(len(p_names)):
    for j in range(len(m_names)):
        objective.SetCoefficient(X[i, j], o_costs[j])  # ✅ 각 변수에 대한 계수 설정
objective.SetMinimization()


status = solver.Solve()        

if status == pywraplp.Solver.OPTIMAL:
    print("Objective value = %.1f" % solver.Objective().Value())
    for i in range(len(p_names)):
        for j in range(len(m_names)):
                print(p_names[i], '/', m_names[j], ': ', \
                      X[i, j].name(), " = %.1f" % X[i, j].solution_value())
else:
    print("The problem does not have an optimal solution.")
#%%실습2
from ortools.linear_solver import pywraplp

solver = pywraplp.Solver.CreateSolver('SCIP')

infinity = solver.infinity()

# 의사결정 변수
x = {i: solver.NumVar(0, infinity, f"x[{i}]") for i in range(5)}
y = {i: solver.NumVar(0, infinity, f"y[{i}]") for i in range(4)}
z = {i: solver.NumVar(0, infinity, f"z[{i}]") for i in range(1, 3)}


# 제약식
solver.Add(x[0] + y[0] <= 2200, 'year1')

solver.Add(x[1] + y[1] + z[1] <= x[0] * 1.08 + (2200 - x[0] - y[0]), 'year2')

solver.Add(x[2] + y[2] + z[2] <= x[1] * 1.08 + y[0] * 1.17 + x[0] * 1.08 + 
           (2200 - x[0] - y[0]) - (x[1] + y[1] + z[1]), 'year3')

solver.Add(x[3] + y[3] <= x[2] * 1.08 + y[1] * 1.17 + z[1] * 1.27 + x[1] * 1.08 + y[0] * 1.17 +
           x[0] * 1.08 + (2200 - x[0] - y[0]) - (x[1] + y[1] + z[1]) - (x[2] + y[2] + z[2]), 'year4')

solver.Add(x[4] <= x[3] * 1.08 + y[2] * 1.17 + z[1] * 1.27 + z[2] * 1.27 + 
           x[2] * 1.08 + y[1] * 1.17 + x[1] * 1.08 + y[0] * 1.17 + x[0] * 1.08 + 
           (2200 - x[0] - y[0]) - (x[1] + y[1] + z[1]) - (x[2] + y[2] + z[2]) - (x[3] + y[3]), 'year5')

# 목적함수
objective = solver.Objective()
obj_expr = [1.08 * x[4] + 1.17 * y[3] + 1.27 * z[2]]
solver.Maximize(solver.Sum(obj_expr))

# 문제 풀이
status = solver.Solve()

if status == pywraplp.Solver.OPTIMAL:
    print("Objective value =", solver.Objective().Value())
    for i in range(5):
        print(x[i].name(), " = ", x[i].solution_value())
    for i in range(4):
        print(y[i].name(), " = ", y[i].solution_value())
    for i in range(1, 3):
        print(z[i].name(), " = ", z[i].solution_value())
else:
    print("The problem does not have an optimal solution.")

