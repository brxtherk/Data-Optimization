# -*- coding: utf-8 -*-
"""
Created on Tue Apr  1 10:54:52 2025

@author: jinuk
"""

from ortools.linear_solver import pywraplp

solver = pywraplp.Solver.CreateSolver("SCIP")
#%% 실습 1
# 데이터
initial_costs = [3, 2, 0]       # 백만 달러
profits = [2, 3, 0.8]           # 백만 달러
capacities = [0.2, 0.4, 0.2]    # 생산용량 비율
max_orders = [3, 2, 5]
BIGM = 10

# 변수 설정
x = []  # 주문 수량
y = []  # 고객 선택 여부 (고정비용 발생 여부)
for i in range(3):
    x.append(solver.IntVar(0, max_orders[i], f"x[{i}]"))
    y.append(solver.IntVar(0, 1, f"y[{i}]"))

# 제약조건: 총 생산 용량 100% 이하
solver.Add(sum(capacities[i] * x[i] for i in range(3)) <= 1.0)

# 제약조건: 선택한 경우에만 생산
for i in range(3):
    solver.Add(x[i] <= max_orders[i] * y[i])

# 제약조건: 모든 주문을 받을 수 없음
solver.Add(sum(y[i] for i in range(3)) <= 2)

# 목적함수: 총 이익 - 초기비용
solver.Maximize(sum(profits[i] * x[i] - initial_costs[i] * y[i] for i in range(3)))

# 풀이
status = solver.Solve()

if status == pywraplp.Solver.OPTIMAL:
    print("OPTIMAL")
    print("Total Profit = ", solver.Objective().Value())
    for i in range(3):
        print(f"Customer {i+1}: Orders = {x[i].solution_value()}")
else:
    print("No optimal solution found.")
#%% 실습2
from ortools.linear_solver import pywraplp

solver = pywraplp.Solver.CreateSolver("SCIP")

BIGM = 1000000

# 수익과 고정비 
profits = [70, 60, 90, 80]
setup_costs = [50000, 40000, 70000, 60000]
n = 4

# 변수 설정
x = [solver.IntVar(0, solver.infinity(), f"x[{i}]") for i in range(n)]  # 생산량
y = [solver.IntVar(0, 1, f"y[{i}]") for i in range(n)]                  # 고정비 발생 여부
z = solver.IntVar(0, 1, "z")                                            # Either-Or 제약 선택용 이진 변수

# 제약 1: 최대 2개의 제품만 선택 생산
solver.Add(sum(y) <= 2)

# 제약 2: 제품 3 또는 4는 제품 1 또는 2가 생산돼야 생산 가능
solver.Add(y[2] <= y[0] + y[1])
solver.Add(y[3] <= y[0] + y[1])

# 제약 3: Either-Or 자재 제약
# Case 1: 5x1 + 3x2 + 6x3 + 4x4 <= 6000 (if z = 0)
solver.Add(5 * x[0] + 3 * x[1] + 6 * x[2] + 4 * x[3] <= 6000 + BIGM * z)
# Case 2: 4x1 + 6x2 + 3x3 + 5x4 <= 6000 (if z = 1)
solver.Add(4 * x[0] + 6 * x[1] + 3 * x[2] + 5 * x[3] <= 6000 + BIGM * (1 - z))

# 생산량은 선택된 경우에만 가능
for i in range(n):
    solver.Add(x[i] <= BIGM * y[i])

# 목적함수: 총 수익 - 고정비용
solver.Maximize(sum(profits[i] * x[i] - setup_costs[i] * y[i] for i in range(n)))

# 풀이
status = solver.Solve()

if status == pywraplp.Solver.OPTIMAL:
    print("OPTIMAL")
    print("총 이익 = ", solver.Objective().Value())
    for i in range(n):
        print(f"제품 {i+1}: 생산량 = {x[i].solution_value()}")
else:
    print("최적해를 찾지 못했습니다.")
#%% 실습3
from ortools.linear_solver import pywraplp

solver = pywraplp.Solver.CreateSolver("SCIP")

n = 5  # 구역 수

# 응답 시간 행렬
response_time = [
    [5, 12, 30, 20, 15],
    [20, 4, 15, 10, 25],
    [15, 20, 6, 15, 12],
    [25, 15, 25, 4, 10],
    [10, 25, 15, 12, 5],
]

# 각 구역별 화재 발생 횟수
fire_freq = [2, 1, 3, 1, 3]

# 변수 선언
x = {}
for i in range(n):
    for j in range(n):
        x[i, j] = solver.IntVar(0, 1, f"x[{i}][{j}]")

y = [solver.IntVar(0, 1, f"y[{i}]") for i in range(n)]  # y[i]: i번 구역에 소방서 설치 여부

# 제약조건 1: 소방서는 정확히 2개 설치
solver.Add(sum(y[i] for i in range(n)) == 2)

# 제약조건 2: 각 구역은 한 군데 소방서에 의해 커버
for j in range(n):
    solver.Add(sum(x[i, j] for i in range(n)) == 1)

# 제약조건 3: 설치된 소방서만 대응 가능
for i in range(n):
    for j in range(n):
        solver.Add(x[i, j] <= y[i])

# 목적함수: 총 응답시간 최소화
objective = solver.Objective()
for i in range(n):
    for j in range(n):
        objective.SetCoefficient(x[i, j], response_time[i][j] * fire_freq[j])
objective.SetMinimization()

# 풀이
status = solver.Solve()

if status == pywraplp.Solver.OPTIMAL:
    print("✅ OPTIMAL")
    print("총 평균 응답 시간 =", solver.Objective().Value(), "분")

    print("\n 소방서 설치 위치:")
    for i in range(n):
        if y[i].solution_value() == 1:
            print(f"  - 구역 {i+1}")
else:
    print("❌ 최적해를 찾을 수 없습니다.")
