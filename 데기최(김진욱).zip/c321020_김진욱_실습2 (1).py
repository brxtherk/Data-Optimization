# -*- coding: utf-8 -*-
"""
Created on Tue Mar 11 11:35:52 2025

@author: jinuk
"""


#%%예제1.1
#의사결정변수: 새콤주스의 생산량=x 달콤주스의 생산량=y
#목적함수: 500*x+400*y
#제약조건식: 4*x+2*y<=30, 2*x+6*y<=40 x,y>=0

from ortools.linear_solver import pywraplp

solver=pywraplp.Solver.CreateSolver('scip')

x=solver.IntVar(0,solver.infinity(),'x')
y=solver.IntVar(0,solver.infinity(),'y')

solver.Add(4*x+2*y<=30)
solver.Add(2*x+6*y<=40)

solver.Maximize(500*x+400*y)

status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print('목적함수값:',solver.Objective().Value() )
    print('새콤주스개수: ',x.solution_value())
    print('달콤주스개수: ',y.solution_value())
else:
    print('최적값이 없음')
    
#%%예제1.2
#의사결정변수: 새콤주스의 생산량=x 달콤주스의 생산량=y
#목적함수: 500*x+400*y
#제약조건식: 4*x+2*y<=30, 2*x+6*y<=45 x,y>=0

from ortools.linear_solver import pywraplp

solver=pywraplp.Solver.CreateSolver('scip')

x=solver.NumVar(0,solver.infinity(),'x')
y=solver.NumVar(0,solver.infinity(),'y')

solver.Add(4*x+2*y<=30)
solver.Add(2*x+6*y<=45)

solver.Maximize(500*x+400*y)

status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print('목적함수값:',solver.Objective().Value() )
    print(f'새콤주스개수: {x.solution_value():.1f}')
    print(f'달콤주스개수:  {y.solution_value():.1f}')
else:
    print('최적값이 없음')
#%%예제2
# 의사결정변수: 식픔1,2,3,4,5,6의 생산량이 각각 x(i) i는 0,1,2,3,4,5
# 목적함수: 350*x0+300*x1+500*x2+340*x3+270*x4+400*x5 을 최소로
# 제약조건:  10*x0+20*x2+20*x3+10*x4+20*x5 >=50
#            10*x1+30*x2+10*x3+30*x4+20*x5 >=60  x(i)>=0

from ortools.linear_solver import pywraplp
solver=pywraplp.Solver.CreateSolver('SCIP')

data={}

data['제약조건 계수']=[[10,0,20,20,10,20],[0,10,30,10,30,20]]
data['영역']=[50,60]
data['목적함수 계수']=[350,300,500,340,270,400]
data['제약조건 개수']=2
data['변수 개수']=6

#의사 결정 변수 만들기
x={}
for i in range(data['변수 개수']):
    x[i]=solver.IntVar(0,solver.infinity(),'x[%i]'%i)

# 제약조건
for i in range(data['제약조건 개수']):
    a=[data['제약조건 계수'][i][j] *x[j] for j in range(data['변수 개수'])]
    solver.Add(sum(a)>=data['영역'][i])

# 목적함수
solver.Minimize(sum(data['목적함수 계수'][i]*x[i] for i in range(data['변수 개수'])))

status=solver.Solve()

if status== pywraplp.Solver.OPTIMAL:
    print('목적함수값: ',solver.Objective().Value())
    for i in range(data['변수 개수']):
        print(x[i].name(),':',x[i].solution_value())
    print('버전: ' ,solver.SolverVersion())
else:
    print('최적해를 찾지 못했습니다')
    
#%% 예제 3
# 의사결정변수 : pawn=x0, Knight=x1, Bishop=x2, King=x3 각각의 생산량(파운드)
# 목적함수: 2*x0+3*x1+4*x2+5*x3 이익의 최대화
# 제약조건: (15*x0+ 10*x1+ 6*x2+ 2*x3)/15 <=750파운드
#            (1*x0+ 6*x1+ 10*x2+ 14*x3)/15 <=250파운드
#           x(i)>=0
# 제약조건의 계수는 온즈 이므로 파운드로 통일 해줘야함

from ortools.linear_solver import pywraplp

solver=pywraplp.Solver.CreateSolver('SCIP')

data={}
data['제약조건 계수']=[[15,10,6,2],[1,6,10,14]]
data['제약조건 영역']=[750,250]
data['목적함수 계수']=[2,3,4,5]
data['제약조건 개수']=2
data['변수 개수']=4

# 의사결정 변수
x={}
for i in range(data['변수 개수']):
    x[i]=solver.IntVar(0,solver.infinity(),'x[%i]' %i)

# 제약조건
for i in range(data['제약조건 개수']):
    a=[data['제약조건 계수'][i][j]/15*x[j] for j in range(data['변수 개수'])]
    solver.Add(sum(a)<=data['제약조건 영역'][i])

# 목적함수
for i in range(data['변수 개수']):
    b=[data['목적함수 계수'][i]*x[i]]
solver.Maximize(sum(b))

status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print('최대 이익은: ',solver.Objective().Value())
    for i in range(data['변수 개수']):
        print(x[i].name(),':',x[i].solution_value())
else:
    print('최적해을 못 찾습니다.')
    

#%%실습1
# 의사결정 변수: food
# 목적함수 총 음식의개수 최소화
# 제약조건 각 영양소의 최소 조건

from ortools.linear_solver import pywraplp
from or2_4_data import*
# 솔버 객체 생성
solver = pywraplp.Solver.CreateSolver("SCIP")

# 의사결정변수
foods = [solver.NumVar(0.0, solver.infinity(), item[0]) for item in data]
# 솔버 객체에 저장된 변수 개수 출력
print("Number of variables =", solver.NumVariables()) 

# 제약조건
constraints = []
for i, nutrient in enumerate(nutrients): #인덱스와 요소를 동시에 불러오기
    constraints.append(solver.Constraint(nutrient[1], solver.infinity())) #solver.Add를 사용하지 않은이유는 제약조건을 저장하기 위함
    for j, item in enumerate(data): # 제약조건에 변수를 추가하고 계수 설정
        constraints[i].SetCoefficient(foods[j], item[i + 3])
print("Number of constraints =", solver.NumConstraints())# 제약조건의 개수


# 목적함수: 가격으로 정규화된 제품 개수의 합을 최소화
objective = solver.Objective()
for food in foods:
    objective.SetCoefficient(food, 1)
objective.SetMinimization()

status = solver.Solve()

# 해 출력: 각 음식별 구매량 출력
nutrients_result = [0] * len(nutrients)
print("\nAnnual Foods:")
for i, food in enumerate(foods):
    if food.solution_value() > 0.0:
        print("{}: ${}".format(data[i][0], 365.0 * food.solution_value()))
        for j, _ in enumerate(nutrients):
            nutrients_result[j] += data[i][j + 3] * food.solution_value()
print("\nOptimal annual price: ${:.4f}".format(365.0 * objective.Value()))
print("\nNutrients per day:")
for i, nutrient in enumerate(nutrients):
    print(
            "{}: {:.2f} (min {})".format(nutrient[0], nutrients_result[i], nutrient[1])
    )
