# -*- coding: utf-8 -*-
"""
Created on Tue Apr 29 10:25:19 2025

@author: jinuk
"""

from ortools.linear_solver import pywraplp

nCity = 6
DIST = [
    [0, 702, 454, 842, 2396, 1196],
    [702, 0, 324, 1093, 2136, 764],
    [454, 324, 0, 1137, 2180, 798],
    [842, 1093, 1137, 0, 1616, 1857],
    [2396, 2136, 2180, 1616, 0, 2900],
    [1196, 764, 798, 1857, 2900, 0]
]

solver = pywraplp.Solver.CreateSolver("SCIP")

# X[i, j]는 도시 i에서 도시 j로 가는지 여부 (0 또는 1)
X = {}
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            X[i, j] = solver.IntVar(0, 1, "X" + str(i) + str(j))

# U[i]는 도시 i의 방문 순서 (순서가 1부터 nCity-1까지)
U = {}
for i in range(1, nCity):
    U[i] = solver.IntVar(1, nCity - 1, "U[%i]" % i)

# 제약조건 1: 도시 j로 한 번은 들어와야 한다.
for j in range(nCity):
    solver.Add(solver.Sum([X[i, j] for i in range(nCity) if i != j]) == 1, 'in_' + str(j))

# 제약조건 2: 도시 j에서 한 번은 나와야 한다.
for i in range(nCity):
    solver.Add(solver.Sum([X[i, j] for j in range(nCity) if i != j]) == 1, 'out_' + str(i))

# 제약조건 3: 방문 순서 제약 
for i in range(1, nCity):
    for j in range(1, nCity):
        if i != j:
            solver.Add(U[i] - U[j] + (nCity - 1) * X[i, j] <= nCity - 2, f'order_{i}_{j}')

# 목표함수: 총 거리 최소화
objective_terms = []
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            objective_terms.append(DIST[i][j] * X[i, j])

solver.Minimize(solver.Sum(objective_terms))

# 문제 해결
status = solver.Solve()

# 결과 출력
if status == pywraplp.Solver.OPTIMAL:
    print("최단 경로:", solver.Objective().Value())
    for i in range(nCity):
        for j in range(nCity):
            if i != j and X[i, j].solution_value() > 0:
                print(f"도시 {i} → 도시 {j}")
else:
    print("해를 찾을 수 없습니다.")
#%%
#%%
#실습1

from ortools.linear_solver import pywraplp

import pandas as pd
import math

nCity = 12

df = pd.read_excel("C:/Users/jinuk/Downloads/tsp_ex_data1.xlsx", index_col = 'Unnamed: 0')
DIST = df.values.tolist()
 
solver = pywraplp.Solver.CreateSolver("SAT")

X = {}
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            X[i, j] = solver.IntVar(0, 1, "X"+str(i)+str(j))
  
U = {}
for i in range(1, nCity):
    U[i] = solver.IntVar(1, nCity-1, "U[%i]" %i)
    
# 제약조건
# 도시j로한번은들어와야한다.
for j in range(nCity):
    solver.Add(solver.Sum([X[i,j] for i in range(nCity) if i != j]) == 1)

# 도시j로부터한번은나와야한다.
for i in range(nCity):
    solver.Add(solver.Sum([X[i,j] for j in range(nCity) if i != j]) == 1)

# 방문순서제약
for i in range(1, nCity):
    for j in range(1, nCity):
        if i != j:
            solver.Add(U[i]-U[j]+12*X[i,j] <= 11)
            solver.Add(2 <= U[i] <= 11)
            

# Objective
objective_terms = []
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            objective_terms.append(DIST[i][j] * X[i, j])

solver.Minimize(solver.Sum(objective_terms))

if 1:
    with open('or9-1.lp', "w") as out_f:
        lp_text = solver.ExportModelAsLpFormat(False)
        out_f.write(lp_text)

# Solve
status = solver.Solve()

# Print solution.
if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE:
    print(f"Total cost = {solver.Objective().Value():.1f}\n", )
    for i in range(nCity):
        for j in range(nCity):
            if i != j:
                if X[i, j].solution_value() > 0.5:
                    print(f"X{i} --> X{j}")
else:
    print("No solution found.")
#%% 실습 2
from ortools.linear_solver import pywraplp
import pandas as pd
import math

# bays29.tsp 파일 읽기
nPos = pd.DataFrame(columns=['xc', 'yc'])

with open("C:/Users/jinuk/Downloads/TSP_data/bays29.tsp", 'r') as f:
    flag = False
    for line in f:
        line = line.strip()
        if line == "NODE_COORD_SECTION":
            flag = True
            continue
        if line == "EOF":
            break
        if flag:
            parts = line.split()
            if len(parts) >= 3:
                nPos.loc[len(nPos)] = [float(parts[1]), float(parts[2])]

# 거리 계산
def calDist(x1, y1, x2, y2):
    return math.hypot(x1 - x2, y1 - y2)

DIST = [[0]*len(nPos) for _ in range(len(nPos))]
for i in range(len(nPos)):
    for j in range(len(nPos)):
        if i != j:
            DIST[i][j] = calDist(nPos['xc'][i], nPos['yc'][i], nPos['xc'][j], nPos['yc'][j])

nCity = len(DIST)

# MILP 모델 세팅
solver = pywraplp.Solver.CreateSolver('SCIP')

X = {}
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            X[i, j] = solver.IntVar(0, 1, f'X[{i},{j}]')

U = {}
for i in range(1, nCity):
    U[i] = solver.IntVar(1, nCity-1, f'U[{i}]')

# 제약조건
for i in range(nCity):
    solver.Add(solver.Sum([X[i, j] for j in range(nCity) if i != j]) == 1)
    solver.Add(solver.Sum([X[j, i] for j in range(nCity) if i != j]) == 1)

for i in range(1, nCity):
    for j in range(1, nCity):
        if i != j:
            solver.Add(U[i] - U[j] + nCity * X[i, j] <= nCity - 1)

# 목적함수
solver.Minimize(
    solver.Sum(DIST[i][j] * X[i, j] for i in range(nCity) for j in range(nCity) if i != j)
)

# LP 파일로 저장
solver.ExportModelAsLpFormat(False, "C:/Users/jinuk/Downloads/bays29.lp")

print("LP 파일로 저장 완료 (C:/Users/jinuk/Downloads/bays29.lp)")


#%% 실습 3

from ortools.linear_solver import pywraplp
import math
import pandas as pd

DIST = [row[:12] for row in DIST[:12]]  # 12x12 거리행렬만 추출

# 2. 기본 세팅
nCity = 12
N = 6  # 방문할 도시 개수

profits = [35000, 13000, 58000, 41000, 13000, 54000, 
           65000, 48000, 69000, 56000, 34000, 67000]

solver = pywraplp.Solver.CreateSolver('SCIP')

# 3. 의사결정변수 정의
X = {}
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            X[i, j] = solver.IntVar(0, 1, f'X[{i},{j}]')

Y = {}
for i in range(nCity):
    Y[i] = solver.IntVar(0, 1, f'Y[{i}]')

U = {}
for i in range(nCity):
    U[i] = solver.IntVar(0, nCity-1, f'U[{i}]')

# 4. 제약조건 설정

# (1) 방문 관련 제약
for i in range(nCity):
    solver.Add(solver.Sum([X[i, j] for j in range(nCity) if i != j]) == Y[i])  # 나가는 것
    solver.Add(solver.Sum([X[j, i] for j in range(nCity) if i != j]) == Y[i])  # 들어오는 것

# (2) 정확히 N개 도시만 방문
solver.Add(solver.Sum([Y[i] for i in range(nCity)]) == N)

# (3) 순환방지 제약 (MTZ 방식)
for i in range(1, nCity):
    for j in range(1, nCity):
        if i != j:
            solver.Add(U[i] - U[j] + (N-1)*X[i,j] <= N-2)

# (4) 방문순서변수 범위
for i in range(1, nCity):
    solver.Add(U[i] >= 0)
    solver.Add(U[i] <= N-1)

# 5. 목적함수 설정 (거리비용 - 수익)
solver.Minimize(
    solver.Sum(DIST[i][j] * X[i, j] for i in range(nCity) for j in range(nCity) if i != j)
    - solver.Sum(profits[i] * Y[i] for i in range(nCity))
)

# 6. 풀기
status = solver.Solve()

if status == pywraplp.Solver.OPTIMAL:
    print(f"목적함수 값: {solver.Objective().Value():.1f}")
    print("\n 방문 도시 리스트:")
    for i in range(nCity):
        if Y[i].solution_value() > 0.5:
            print(f"도시 {i}")

    print("\n 이동 경로:")
    for i in range(nCity):
        for j in range(nCity):
            if i != j and X[i, j].solution_value() > 0.5:
                print(f"{i} ➔ {j}")
else:
    print("❌ 최적해를 찾지 못했습니다.")
#%% 휴리스틱으로 실습 2번


import pandas as pd
import math

# bays29.tsp 파일 읽기
nPos = pd.DataFrame(columns=['xc', 'yc'])

with open("C:/Users/jinuk/Downloads/TSP_data/bays29.tsp", 'r') as f:
    flag = False
    for line in f:
        line = line.strip()
        if line == "NODE_COORD_SECTION":
            flag = True
            continue
        if line == "EOF":
            break
        if flag:
            parts = line.split()
            if len(parts) >= 3:
                nPos.loc[len(nPos)] = [float(parts[1]), float(parts[2])]

# 거리 계산 함수
def calDist(x1, y1, x2, y2):
    return math.hypot(x1 - x2, y1 - y2)

nCity = len(nPos)

# 거리 행렬 만들기
DIST = [[0]*nCity for _ in range(nCity)]
for i in range(nCity):
    for j in range(nCity):
        if i != j:
            DIST[i][j] = calDist(nPos['xc'][i], nPos['yc'][i], nPos['xc'][j], nPos['yc'][j])

# Nearest Neighbor 알고리즘
visited = [False] * nCity
route = []
current = 0
visited[current] = True
route.append(current)
total_distance = 0

for _ in range(nCity - 1):
    nearest = None
    nearest_dist = float('inf')
    for j in range(nCity):
        if not visited[j] and DIST[current][j] < nearest_dist:
            nearest = j
            nearest_dist = DIST[current][j]
    route.append(nearest)
    visited[nearest] = True
    total_distance += nearest_dist
    current = nearest

# 다시 출발점으로 복귀
total_distance += DIST[current][route[0]]
route.append(route[0])

# 결과 출력
print(f"근사 총 거리: {total_distance:.1f}")
print("방문 순서:", route)

    






