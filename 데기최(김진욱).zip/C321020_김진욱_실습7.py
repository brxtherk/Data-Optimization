# -*- coding: utf-8 -*-
"""
Created on Tue Apr 15 10:17:28 2025

@author: jinuk
"""

#%% 실습1
from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver("SCIP")
M=1000000
infinity=solver.infinity()

costs = [
    [41, 27, 28, 24],
    [40, 29, M, 23],
    [37, 30, 27, 21]
]
supplies=[75,75,45]
need=[20,30,30,40]
#의사결정변수
x = {}
for i in range(3):
    for j in range(4):
        x[i, j] = solver.IntVar(0, infinity, f"x[{i},{j}]")
#제약조건
for i in range(3):
    solver.Add(sum(x[i, j] for j in range(4)) <= supplies[i])

for j in range(4):
    solver.Add(sum(x[i, j] for i in range(3)) == need[j])
#목적함수
solver.Minimize(sum(costs[i][j] * x[i, j] for i in range(3) for j in range(4)))

status = solver.Solve()

if status == pywraplp.Solver.OPTIMAL:
    print("목적함수값 = ", solver.Objective().Value())
    for i in range(3):
        for j in range(4):
            if x[i,j].solution_value() >0:
                print(f"공장{i+1} → 제품{j+1}: {x[i,j].solution_value()}")
#수송문제로
# 생산 비용 행렬 (공장3개 × 제품4개 + 더미수요지)
costs = [
    [41, 27, 28, 24, 0],  # 공장1
    [40, 29, M, 23, 0],   # 공장2 (제품3 생산 불가)
    [37, 30, 27, 21, 0]   # 공장3
]

# 공급량 (공장별 생산가능량)
supplies = [75, 75, 45]

# 수요량 (제품별 수요 + 더미수요지)
demands = [20, 30, 30, 40, 75]  # 더미 수요지 수요 = 남는 공급량

num_factory = len(supplies)
num_product = len(demands)

# 의사결정변수
x = {}
for i in range(num_factory):
    for j in range(num_product):
        x[i, j] = solver.IntVar(0, infinity, f"x[{i},{j}]")

# 제약조건 - 공급량
for i in range(num_factory):
    solver.Add(solver.Sum(x[i, j] for j in range(num_product)) <= supplies[i])

# 제약조건 - 수요량
for j in range(num_product):
    solver.Add(solver.Sum(x[i, j] for i in range(num_factory)) == demands[j])

# 목적함수 - 총비용 최소화
solver.Minimize(solver.Sum(costs[i][j] * x[i, j] for i in range(num_factory) for j in range(num_product)))

# 최적화 수행
status = solver.Solve()

# 결과 출력
if status == pywraplp.Solver.OPTIMAL:
    print("목적함수값 =", solver.Objective().Value())
    for i in range(num_factory):
        for j in range(num_product):
            if x[i, j].solution_value() > 0:
                print(f"공장{i+1} → 제품{j+1}: {x[i, j].solution_value()}")

else:
    print("해를 찾을 수 없습니다.")
#%%실습2

from ortools.linear_solver import pywraplp

solver = pywraplp.Solver.CreateSolver("SCIP")
M = 1000000  # 매우 큰 값

costs = [
    [500, 400, 600, 700],
    [600, 600, 700, 500],
    [700, 500, 700, 600],
    [500, 400, 600, 600]
]

num_ships = len(costs)
num_ports = len(costs[0])

x = {}
for i in range(num_ships):
    for j in range(num_ports):
        x[i, j] = solver.IntVar(0, 1, f"x[{i},{j}]")

# 각 선박은 하나의 항구만 갈 수 있음
for i in range(num_ships):
    solver.Add(solver.Sum(x[i, j] for j in range(num_ports)) == 1)

# 각 항구는 하나의 선박만 배정받음
for j in range(num_ports):
    solver.Add(solver.Sum(x[i, j] for i in range(num_ships)) == 1)

solver.Minimize(solver.Sum(costs[i][j] * x[i, j] for i in range(num_ships) for j in range(num_ports)))

status = solver.Solve()

if status == pywraplp.Solver.OPTIMAL:
    print("목적함수값 =", solver.Objective().Value())
    for i in range(num_ships):
        for j in range(num_ports):
            if x[i, j].solution_value() > 0:
                print(f"선박{i+1} → 항구{j+1}")
#수송문제
M = 1000000

costs = [
    [500, 400, 600, 700],
    [600, 600, 700, 500],
    [700, 500, 700, 600],
    [500, 400, 600, 600]
]

num_ships = len(costs)
num_ports = len(costs[0])

x = {}
for i in range(num_ships):
    for j in range(num_ports):
        x[i, j] = solver.IntVar(0, 1, f"x[{i},{j}]")

# 각 선박은 하나의 항구만 갈 수 있음
for i in range(num_ships):
    solver.Add(solver.Sum(x[i, j] for j in range(num_ports)) == 1)

# 각 항구는 하나의 선박만 배정받음
for j in range(num_ports):
    solver.Add(solver.Sum(x[i, j] for i in range(num_ships)) == 1)

solver.Minimize(solver.Sum(costs[i][j] * x[i, j] for i in range(num_ships) for j in range(num_ports)))

status = solver.Solve()

if status == pywraplp.Solver.OPTIMAL:
    print("목적함수값 =", solver.Objective().Value())
    for i in range(num_ships):
        for j in range(num_ports):
            if x[i, j].solution_value() > 0:
                print(f"선박{i+1} → 항구{j+1}")
#%%실습3
from ortools.linear_solver import pywraplp

solver = pywraplp.Solver.CreateSolver("SCIP")

# 시간(비용)을 10배한 정수값으로 변환한 비용 행렬 (선수 5명 × 종목 5개(더미 포함))
costs = [
    [377, 434, 333, 292, 0],  # Carl
    [329, 331, 285, 264, 0],  # Chris
    [338, 422, 389, 296, 0],  # David
    [370, 347, 304, 285, 0],  # Tony
    [354, 418, 336, 311, 0],  # Ken
]

supplies = [1, 1, 1, 1, 1]  # 선수 5명 (각 1명씩 배정 가능)
demands = [1, 1, 1, 1, 1]   # 종목 4개 + 더미 수요 1

num_swimmers = len(supplies)
num_strokes = len(demands)

x = {}
for i in range(num_swimmers):
    for j in range(num_strokes):
        x[i, j] = solver.IntVar(0, 1, f"x[{i},{j}]")

# 제약조건
for i in range(num_swimmers):
    solver.Add(solver.Sum(x[i, j] for j in range(num_strokes)) <= 1)

for j in range(num_strokes):
    solver.Add(solver.Sum(x[i, j] for i in range(num_swimmers)) == 1)

# 목적함수
solver.Minimize(solver.Sum(costs[i][j] * x[i, j] for i in range(num_swimmers) for j in range(num_strokes)))

status = solver.Solve()

if status == pywraplp.Solver.OPTIMAL:
    print("총 최소 시간:", solver.Objective().Value() / 10, "초")
    for i in range(num_swimmers):
        for j in range(num_strokes - 1):  # 더미 제외
            if x[i, j].solution_value() > 0:
                print(f"선수 {i+1} → 종목 {j+1}")
else:
    print("해를 찾을 수 없습니다.")

