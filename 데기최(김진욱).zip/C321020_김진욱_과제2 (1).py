# -*- coding: utf-8 -*-
"""
Created on Mon Mar 24 22:59:29 2025

@author: jinuk
"""

# 과제 2-1
# 의사결정변수: 각 목재회사에서 공장으로의 공급할 목재량(톤)
#제약조건:
#수요/x00+x10+x20>=500, x01+x11+x21>=700, x02+x12+x22>=600
#공급제약/x20+x21+x22<=500
#수송제약/x10,x11,x12<=200/x20,x21,x22<=200
 
from ortools.linear_solver import pywraplp
solver=pywraplp.Solver.CreateSolver('SCIP')

company=[1,2,3]
facility=[1,2,3]
cost=[[2,3,5],[2.5,4,4.8],[3,3.6,3.2]]
need=[500,700,600]

#의사결정 변수
x={}
for i in range(len(company)):
    for j in range(len(facility)):
        x[i,j]=solver.NumVar(0,solver.infinity(),'x'+str(i)+str(j))

#제약조건
#수요제약
for j in range(len(facility)):
        a=[x[i,j] for i in range(len(company)) ]
        solver.Add(sum(a)>=need[j])
#공급제약
b=[x[2,j] for j in range(len(facility))]
solver.Add(sum(b)<=500)

#수송제약
for i in range(1,len(company)):
    for j in range(len(facility)):
        solver.Add(x[i,j]<=200)

#목적함수
c=[]
for i in range(len(company)):
    for j in range(len(facility)):
        c.append(x[i,j] *cost[i][j])
solver.Minimize(solver.Sum(c))
        
status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print('목적함수 값은?',solver.Objective().Value())
    for i in range(len(company)):
        for j in range(len(facility)):
                print(f'{company[i]}번 회사/ {facility[j]}번 공장/ {x[i,j].name()}/ {x[i,j].solution_value()}')
else:
    print('최적값을 모르겠습니다.')
    
#%%과제 2-1
# 의사결정변수 저소득주택수 X 중간소득주택수 Y
# 제약조건
# 60<=X<=100 / 30<=Y<=70
# 13000*X + 18000*Y <= 2000000
# X >= Y/2 + 50
# 목적함수
# 13000*X + 18000*Y 최대화
# 의사결정변수
from ortools.linear_solver import pywraplp
solver=pywraplp.Solver.CreateSolver('SCIP')

X = solver.IntVar(60, 100, "X")
Y = solver.IntVar(30, 70, "Y")

# 제약조건
solver.Add(X/20+ Y/15 <= 10)
solver.Add(X + Y <= 150)
solver.Add(13000*X + 18000*Y <= 2000000)
solver.Add(X >= Y/2 + 50)

 # 목적함수
solver.Minimize(13000*X + 18000*Y)

status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print(f'목적함수값= {solver.Objective().Value():.1f}')
    print(f'저소득주택= {X.solution_value()}')
    print(f'중간소득주택= {Y.solution_value()}')
else:
    print('최적값 없음')

#%%과제 2-2
# X+Y 최소화
# 의사결정변수
 
from ortools.linear_solver import pywraplp
solver=pywraplp.Solver.CreateSolver('SCIP')

X = solver.IntVar(60, 100, "X")
Y = solver.IntVar(30, 70, "Y")
# 제약조건
solver.Add(X/20 + Y/15 <= 10)
solver.Add(X + Y<= 150)
solver.Add(13000*X + 18000*Y <= 2000000)
solver.Add(X >= Y/2 + 50)

# 목적함수
solver.Maximize(X +Y)
    
status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print(f'목적함수값= {solver.Objective().Value():.1f}')
    print(f'저소득주택= {X.solution_value()}')
    print(f'중간소득주택= {Y.solution_value()}')
else:
    print('최적값 없음')