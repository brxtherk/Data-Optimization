# -*- coding: utf-8 -*-
"""
Created on Tue Mar 25 10:37:04 2025

@author: jinuk
"""
#%% 문제 4-1
from ortools.linear_solver import pywraplp

def main():
    # Create the mip solver with the SCIP backend.
    solver = pywraplp.Solver.CreateSolver("SAT")
    if not solver:
        return

    infinity = solver.infinity()
    # x = solver.IntVar(0.0, infinity, "x")
    # y = solver.IntVar(0.0, infinity, "y")

    x = solver.NumVar(0.0, infinity, "x")
    y = solver.NumVar(0.0, infinity, "y")

    # 제약조건
    solver.Add(x + 7 * y <= 17.5)
    solver.Add(x <= 3.5)

    # 목적함수
    solver.Maximize(x + 10 * y)

    print(f"Solving with {solver.SolverVersion()}")

    status = solver.Solve()

    if status == pywraplp.Solver.OPTIMAL:
        print("Solution:")
        print("Objective value =", solver.Objective().Value())
        print("x =", x.solution_value())
        print("y =", y.solution_value())
    else:
        print("The problem does not have an optimal solution.")

if __name__ == "__main__":
    main()
#%%문제 4-2
from ortools.linear_solver import pywraplp

# SAT 기반 solver 생성
solver = pywraplp.Solver.CreateSolver("SAT")

# 요일별 요구 인원 수
REQ = [20, 16, 13, 16, 19, 14, 12]

names = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN']

infinity = solver.infinity()

# 변수 선언: x[i] = i요일에 근무 시작한 직원 수
x = {}
for i in range(7):
    x[i] = solver.IntVar(0, infinity, f"x[{i}]")

# 제약조건: 각 요일마다 필요한 인원 수 이상 근무 중이어야 함
for i in range(7):
    constraint_expr = [x[(i - j) % 7] for j in range(5)]
    solver.Add(sum(constraint_expr) >= REQ[i], names[i])

# 목적함수: 총 직원 수 최소화
objective = solver.Objective()
objective.SetMinimization()
objective.SetCoefficient(x[0], 1)
objective.SetCoefficient(x[1], 1)
objective.SetCoefficient(x[2], 1)
objective.SetCoefficient(x[3], 1)
objective.SetCoefficient(x[4], 1)
objective.SetCoefficient(x[5], 1)
objective.SetCoefficient(x[6], 1)

# 모델 파일 저장 (선택사항)
with open("or4-2.lp", "w") as out_f:
    lp_text = solver.ExportModelAsLpFormat(False)
    out_f.write(lp_text)

# 최적화 수행
status = solver.Solve()

# 결과 출력
if status == pywraplp.Solver.OPTIMAL:
    print("✅ 최적해 찾음!")
    print("총 직원 수 (Objective value) =", solver.Objective().Value())
    for i in range(7):
        print(f"{names[i]} 시작 직원 수 = {x[i].solution_value()}")
else:
    print("❌ 최적해를 찾지 못했습니다.")
#%%문제 4-3
from ortools.linear_solver import pywraplp

# SAT 기반 solver 생성
solver = pywraplp.Solver.CreateSolver("SAT")

#요구인원
req=[2,2,2,2,2,2,8,8,8,8,4,4,3,3,3,3,6,6,5,5,5,5,3,3]
infinity=solver.infinity()

#의사결정변수
x={}
for i in range(len(req)):
    x[i]=solver.IntVar(0,infinity,f'x[{i}]')
#제약조건
for i in range(len(req)):
    a=[]
    for j in range(len(req)):
        if (i-j)%24 in [0,1,2,3,5,6,7,8]:
            a.append(x[j])
    solver.Add(sum(a)>=req[i])
#목적함수
objective=solver.Objective()
solver.Minimize(solver.Sum(x[i] for i in range(len(req))))
#출력
status = solver.Solve()

if status == pywraplp.Solver.OPTIMAL:
    print("최적해 찾음!")
    print("총 직원 수 (Objective value) =", solver.Objective().Value())
    for i in range(len(req)):
        print(f"{i} 시작 직원 수 = {x[i].solution_value()}")
else:
    print("최적해를 찾지 못했습니다.")
#%%문제 4-4
solver = pywraplp.Solver.CreateSolver("SCIP")

#계수
Ratings = [
        [None, 9, 3, 4, 2, 1, 5, 6],
        [None, None, 1, 7, 3, 5, 2, 1],
        [None, None, None, 4, 4, 2, 9, 2],
        [None, None, None, None, 1, 5, 5, 2],
        [None, None, None, None, None, 8, 7, 6],
        [None, None, None, None, None, None, 2, 3],
        [None, None, None, None, None, None, None, 4]
    ]
n=8#(에이전트 인원)
#의사결정변수

x={}

for i in range(n):
    for j in range(i+1,n):  
        x[i,j]= solver.IntVar(0,1,f'x[{i},{j}') 
#제약조건
for i in range(n):
    expr = []
    for j in range(n):
        if i == j:
            continue  # 자기 자신과 팀 안 맺음
        if i < j and (i, j) in x:
            expr.append(x[i, j])
        elif j < i and (j, i) in x:
            expr.append(x[j, i])
    solver.Add(sum(expr) == 1)

#목적함수
objective = solver.Objective()
for i in range(n):
   for j in range(i+1,n):
       objective.SetCoefficient(x[i,j],Ratings[i][j])

objective.SetMaximization()

with open('or4-3.lp', "w") as out_f:
    lp_text = solver.ExportModelAsLpFormat(False)
    out_f.write(lp_text)

status = solver.Solve()
if status == pywraplp.Solver.OPTIMAL:
    print("최적해를 찾았습니다!")
    print("팀 구성:")
    
    for i in range(n):
        for j in range(i + 1, n):  # 정의된 변수만 확인
            if x[i, j].solution_value() > 0.5:  # 값이 1이면 선택된 팀
                print(f"컨설턴트 {i+1} - {j+1}")
    
    print("\n총 팀워크 점수 =", solver.Objective().Value())
else:
    print("최적해를 찾지 못했습니다.")
#%% 추가실습1
from ortools.linear_solver import pywraplp

# SCIP 솔버를 이용하여 새로운 선형 프로그래밍 솔버 생성
solver = pywraplp.Solver.CreateSolver('SCIP')

# 활동에 대한 변수를 생성 (0 또는 1의 값을 가질 수 있음)
ME = solver.BoolVar('ME')
MS = solver.BoolVar('MS')
CE = solver.BoolVar('CE')
CS = solver.BoolVar('CS')
DE = solver.BoolVar('DE')
DS = solver.BoolVar('DS')
LE = solver.BoolVar('LE')
LS = solver.BoolVar('LS')

# 목적 함수 설정: 각 활동에 대한 시간을 최소화
solver.Minimize(4.5 * ME + 7.8 * CE + 3.6 * DE + 2.9 * LE +
                4.9 * MS + 7.2 * CS + 4.3 * DS + 3.1 * LS)

#제약 조건
solver.Add(ME + MS == 1) 
solver.Add(CE + CS == 1) 
solver.Add(DE + DS == 1)
solver.Add(LE + LS == 1) 
solver.Add(ME+CE+DE+LE==2)
solver.Add(MS+CS+DS+LS==2)
# 솔버 실행
status = solver.Solve()

# 결과 출력
if status == pywraplp.Solver.OPTIMAL:
    print('Solution:')
    print('ME =', ME.solution_value())
    print('MS =', MS.solution_value())
    print('CE =', CE.solution_value())
    print('CS =', CS.solution_value())
    print('DE =', DE.solution_value())
    print('DS =', DS.solution_value())
    print('LE =', LE.solution_value())
    print('LS =', LS.solution_value())
    print("집안일 시간=", solver.Objective().Value())
else:
    print('The problem does not have an optimal solution.')

#%% 추가실습2
from ortools.linear_solver import pywraplp

solver = pywraplp.Solver.CreateSolver('SCIP')

infinity = solver.infinity()

# 의사결정 변수

x = {}
for i in range(7):
    x[i]=solver.NumVar(0,infinity, "x[%i]" %i)
    
    
from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver("SAT")

num1 = [17,10,15,19,7,13,9]
num2 = [43,28,34,48,17,32,23]


# 의사결정 변수
x = {}
for i in range(7):
    x[i] = solver.IntVar(0, 1, "x"+str(i))
        
# 제약조건
solver.Add(sum([num2[i]*x[i] for i in range(7)])<=100)
solver.Add(x[0]+x[1]<=1)
solver.Add(x[2]+x[3]<=1)
solver.Add(x[2]<=x[0]+x[1])
solver.Add(x[3]<=x[0]+x[1])

# 목적함수
obj_expr = []

for i in range(7):
        obj_expr.append(x[i]*num1[i])
        
solver.Maximize(solver.Sum(obj_expr))

status = solver.Solve()


if status == pywraplp.Solver.OPTIMAL:
    print("Objective value =%.1f" %(solver.Objective().Value()))
    for i in range(7):
                print(x[i], " = ", x[i].solution_value())
else:
    print("The problem does not have an optimal solution.")


#%% 추가문제3
solver = pywraplp.Solver.CreateSolver("SCIP")

#의사결정변수

sup=[60,80,40]
profit=[[800,700,500,200],[500,200,100,300],[600,400,300,500]]

fac=3

con=4

infinity=solver.infinity()

x={}
for i in range(fac):
    for j in range(con):
        x[i,j]=solver.IntVar(0,infinity,f'{i+1}공장에서 {j+1}번 소비자')

#제약조건
for i in range(fac):
    solver.Add(sum(x[i,j] for j in range(con))<=sup[i])
    
solver.Add(sum(x[i,2] for i in range(fac))>=20)

solver.Add(sum(x[i,0] for i in range(fac))==40)

solver.Add(sum(x[i,1] for i in range(fac))==60)
#목적함수
objective = solver.Objective()

for i in range(fac):
    for j in range(con):
        objective.SetCoefficient(x[i,j],profit[i][j])
objective.SetMaximization()

status = solver.Solve()

if status == pywraplp.Solver.OPTIMAL:
    print("최적해를 찾았습니다!")
    total_profit = solver.Objective().Value()
    print("총 수익 =", total_profit)
    for i in range(fac):
        for j in range(con):
            if x[i,j].solution_value()!=0:
                print(f'{x[i,j].name()}={x[i,j].solution_value()}')
else:
    print("최적해를 찾지 못함")


    