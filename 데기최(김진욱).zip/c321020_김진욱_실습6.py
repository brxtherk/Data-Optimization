# -*- coding: utf-8 -*-
"""
Created on Tue Apr  8 11:40:36 2025

@author: jinuk
"""
#%% 문제1
from ortools.linear_solver import pywraplp
solver=pywraplp.Solver.CreateSolver('SCIP')

cost=[[90,80,75,70],[35,85,55,65],[125,95,90,95],[45,110,95,115],[50,100,90,100]]

x={}
for i in range(5):
    for j in range(4):
        x[i,j]=solver.IntVar(0,1,f'x{i}{j}')
# 작업자는 1개 이하의 과업        
for i in range(5):
    solver.Add(sum([x[i,j] for j in range(4)])<=1)
#과업은 작업자가 1명 배정받아야함   
for j in range(4):
    solver.Add(sum([x[i,j] for i in range(5)])==1)
a=[]  
for i in range(5):
    for j in range(4):
        a.append(x[i,j]*cost[i][j])

solver.Minimize(solver.Sum(a))

status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print('최적값은?',solver.Objective().Value())
    for i in range(5):
        for j in range(4):
            print(f'{i}작업자/{j}과업',x[i,j].name(),x[i,j].solution_value())
    
    
#%% 문제2

from ortools.linear_solver import pywraplp

# 작업별 인건비 (작업자 i가 작업 j를 수행할 때의 비용)
cost = [
    [90, 76, 75, 70],
    [35, 85, 55, 65],
    [125, 95, 90, 105],
    [45, 110, 95, 115],
    [60, 105, 80, 75],
    [45, 65, 110, 95]
]

# 작업자 수, 과업 수
num_workers = 6
num_tasks = 4

# 팀 구성
team1 = [0, 2, 4]  # 팀 1: 0번, 2번, 4번 작업자
team2 = [1, 3, 5]  # 팀 2: 1번, 3번, 5번 작업자

# solver 생성
solver = pywraplp.Solver.CreateSolver("SCIP")

# 의사결정변수 x[i,j]: 작업자 i가 작업 j를 수행하면 1, 아니면 0
x = {}
for i in range(num_workers):
    for j in range(num_tasks):
        x[i, j] = solver.IntVar(0, 1, f'x[{i},{j}]')

# 제약조건 1: 각 작업자는 최대 하나의 과업만 수행할 수 있음
for i in range(num_workers):
    solver.Add(solver.Sum(x[i, j] for j in range(num_tasks)) <= 1)

# 제약조건 2: 각 과업은 정확히 한 명의 작업자가 맡아야 함
for j in range(num_tasks):
    solver.Add(solver.Sum(x[i, j] for i in range(num_workers)) == 1)

# 제약조건 3: 팀1이 수행하는 전체 과업 수는 2개 이하
team1_jobs = []
for i in team1:
    for j in range(num_tasks):
        team1_jobs.append(x[i, j])
solver.Add(solver.Sum(team1_jobs) <= 2)

# 제약조건 4: 팀2도 최대 2개의 과업만 수행 가능
team2_jobs = []
for i in team2:
    for j in range(num_tasks):
        team2_jobs.append(x[i, j])
solver.Add(solver.Sum(team2_jobs) <= 2)

# 목적함수: 총 인건비(작업 배정 비용)의 합을 최소화
objective_terms = []
for i in range(num_workers):
    for j in range(num_tasks):
        objective_terms.append(cost[i][j] * x[i, j])
solver.Minimize(solver.Sum(objective_terms))

status = solver.Solve()

if status == pywraplp.Solver.OPTIMAL:
    print(f"총 최소 비용: {solver.Objective().Value():.1f}\n")
    for i in range(num_workers):
        for j in range(num_tasks):
            if x[i, j].solution_value() > 0.5:
                print(f"작업자 {i} → 과업 {j} (비용: {cost[i][j]})")

#%% 문제3
from ortools.linear_solver import pywraplp

# Data
costs = [
    [90, 76, 75, 70, 50, 74, 12, 68],
    [35, 85, 55, 65, 48, 101, 70, 83],
    [125, 95, 90, 105, 59, 120, 36, 73],
    [45, 110, 95, 115, 104, 83, 37, 71],
    [60, 105, 80, 75, 59, 62, 93, 88],
    [45, 65, 110, 95, 47, 31, 81, 34],
    [38, 51, 107, 41, 69, 99, 115, 48],
    [47, 85, 57, 71, 92, 77, 109, 36],
    [39, 63, 97, 49, 118, 56, 92, 61],
    [47, 101, 71, 60, 88, 109, 52, 90],
]
num_workers = 10
num_tasks = 8
task_sizes = [10, 7, 3, 12, 15, 4, 11, 5]
total_size_max = 15


solver = pywraplp.Solver.CreateSolver("SCIP")

#의사결정변수 설정
x = {}
for worker in range(num_workers):
    for task in range(num_tasks):
        x[worker, task] = solver.BoolVar(f"x[{worker},{task}]")


#제약조건
#작업자
for worker in range(num_workers):
    solver.Add(solver.Sum(task_sizes[task]*x[worker,task] for task in range(num_tasks))<=total_size_max)
   
#업무
for task in range(num_tasks):
    solver.Add(solver.Sum(x[worker,task] for worker in range(num_workers))==1)

#목적함수
Objective_teams =[]
for worker in range(num_workers):
    for task in range(num_tasks):
        Objective_teams.append(costs[worker][task]*x[worker,task])

solver.Minimize(solver.Sum(Objective_teams))

with open('or6-1.lp', "w") as out_f:
    lp_text = solver.ExportModelAsLpFormat(False)
    out_f.write(lp_text)

status = solver.Solve()

if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE:
    print(f"Total cost = {solver.Objective().Value()}\n")


    for worker in range(num_workers):
        for task in range(num_tasks):
            if x[worker, task].solution_value() > 0.5:
                print(f"Worker {worker} assigned to task {task}." + f" Cost: {costs[worker][task]}")

else:
    print("No solution found.")
    
#%% 문제4
from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver("SCIP")
costs = [50, 40, 60, 47.5, 55, 30, 57.5, 57.2]
sa = [
      [1, 0, 0, 1, 0, 0],
      [0, 1, 1, 0, 0, 0],
      [0, 1, 0, 0, 0, 1],
      [1, 0, 0, 0, 0, 1],
      [0, 0, 0, 1, 0, 1],
      [0, 0, 1, 0, 0, 0],
      [0, 1, 1, 0, 1, 0],
      [1, 0, 0, 0, 1, 0]
]
nloc = len(sa)
# 의사결정변수
x = {}
for i in range(nloc):
    x[i] = solver.BoolVar(f"x[{i}]")
# 제약조건
for i in range(len(sa[0])):
    solver.Add(sum([sa[ j][i] * x[ j] for j in range(nloc)]) >= 1, 'location_'+str(i))
# 목적함수
solver.Minimize(sum([costs[i]*x[i] for i in range(nloc)]))
with open('or6-4.lp', "w") as out_f:
    lp_text = solver.ExportModelAsLpFormat(False)
    out_f.write(lp_text)
status = solver.Solve()
if status == pywraplp.Solver.OPTIMAL:
    print("OPTIMAL")
    print(f"목적함수값 = {solver.Objective().Value():.1f}")
    for i in range(nloc):
        print(x[i].name(), " = ", x[i].solution_value())
else:
    print("The problem does not have an optimal solution.")
    
#%% 문제5
from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver("SCIP")
infinity = solver.infinity()
patterns = [
    [3, 0, 0],
    [1, 1, 0],
    [0, 2, 0],
    [1, 0, 1]
]
products = [16, 24, 30]
demands = [400, 120, 80]
nPats = len(patterns)
nProducts = len(products)
# 의사결정변수
x = {}
for i in range(nPats):
    x[i] = solver.IntVar(0, infinity, f"x[{i}]")
# 제약조건
for i in range(nProducts):
    solver.Add(sum([patterns[j][i]*x[j] for j in range(nPats)])>= demands[i],'dp_'+str(i))
# 목적함수

solver.Minimize(sum([500*x[i] for i in range(nPats)]))
with open('or6-5.lp', "w") as out_f:
    lp_text = solver.ExportModelAsLpFormat(False)
    out_f.write(lp_text)
status = solver.Solve()
if status == pywraplp.Solver.OPTIMAL:
    print("OPTIMAL")
    print(f"목적함수값 = {solver.Objective().Value():.1f}")
    for i in range(nPats):
        print(x[i].name(), " = ", x[i].solution_value())
else:
    print("The problem does not have an optimal solution.")
#%% 문제6
from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver("SCIP")
infinity = solver.infinity()

import matplotlib.pyplot as plt
limits = [
    [3500, 3655], [3520, 3905], [3600, 3658], [3650, 4075], [3660, 3915],
    [3900, 4449], [3910, 4095], [3950, 4160], [3995, 4065], [4000, 4195],
    [4000, 4200], [4210, 4405], [4320, 4451], [4350, 4500], [4420, 5400],
    [4450, 4800], [4450, 4570], [5200, 6000], [5600, 6200], [6010, 6400],
    [6015, 6250]
]

names = ['PBD', 'PPO', 'PPF', 'PBO', 'PPD', 'POPOP', 'A-NPO', 'NASAL', 'AMINOB', 'BBO', 'D-STILB',
'D-POPOP', 'A-NOPON', 'D-ANTH', '4-METHYL-V', '7-D-4-M', 'ESCULIN', 'NA-FLUOR', 
'RHODAMINE-6G', 'RHODAMINE-B', 'ACRIDINE-RED']


limits = [ [3500, 3655], [3520, 3905], [3600, 3658], [3650, 4075], [3660, 3915], [3900, 4449], [3910, 4095], [3950, 4160], [3995, 4065], [4000, 4195], [4000, 4200], [4210, 4405], [4320, 4451], [4350, 4500], [4420, 5400], [4450, 4800], [4450, 4570], [5200, 6000], [5600, 6200], [6010, 6400], [6015, 6250] ]


fig, ax = plt.subplots(figsize=(10, 8))
# Plotting each interval
for idx, (start, end) in enumerate(limits):
    ax.plot([start, end], [idx] * 2, linewidth = 2.0, marker = '|', color='blue', markersize=10)
# Improving the layout
ax.set_yticks(range(len(limits))) # Set the y-ticks to match the number of intervals
ax.set_yticklabels([f"{i+1}. {names[i]}" for i in range(len(limits))]) # Label each interval
ax.set_xlabel("Value")
ax.set_title("Visualization of Intervals")
plt.tight_layout()
plt.show()
max_val, min_val = max(sum(limits, [])), min(sum(limits, []))
# 화학약품 번호 0 부터
coverages = {}
for val in range(min_val, max_val+1):
    cover = []
    for i in range(len(limits)):
        if limits[i][0] <= val and limits[i][1] >= val:
            cover.append(i)
    coverages[val] = cover
# 해당 범위 커버하는 약품 set이 달라지는 구간
intervals = {}
start = min_val
for i in range(min_val, max_val):
    if coverages[i] == coverages[i+1]: 
        continue
    intervals[start] = [start, i]
    start = i + 1
intervals[start] = [start, max_val]

costs = [4, 3, 1, 4, 1, 6, 2, 3, 1, 2, 2, 2, 2, 2, 9, 3, 1, 9, 8, 8, 2]
# 의사결정변수
x = {}
for i in range(len(names)):
    x[i] = solver.IntVar(0, infinity, f"x[{i}]")
# 제약조건: 각 구간에 커버하는 하나 이상 약품 필요

for key in intervals.keys():
    solver.Add(sum([x[j]for j in coverages[key]])>=1, str(intervals[key]))

# 목적함수
solver.Minimize(sum([costs[i]*x[i] for i in range(len(names))]))
with open('or6-6.lp', "w") as out_f:
    lp_text = solver.ExportModelAsLpFormat(False)
    out_f.write(lp_text)
status = solver.Solve()
if status == pywraplp.Solver.OPTIMAL:
    print("OPTIMAL")
    print(f"목적함수값 = {solver.Objective().Value():.1f}")
    for i in range(len(names)):
        print(x[i].name(), " = ", x[i].solution_value())
else:
    print("The problem does not have an optimal solution.")
#%%문제7
from ortools.linear_solver import pywraplp

solver = pywraplp.Solver.CreateSolver("SCIP")

coverage = [
    [0, 2, 3, 5, 6],       
    [3, 6, 7, 11],         
    [1, 4, 8, 10, 12],    
    [0, 1, 13, 14],       
    [2, 5, 9, 11, 13],    
    [7, 13, 14],          
    [0, 1, 5, 10],        
    [0, 1, 3, 5, 7, 11],   
]

num_cameras = len(coverage)
num_zones = 15

# 변수
x = [solver.IntVar(0, 1, f'x{i}') for i in range(num_cameras)]

# 제약조건: 각 경기장 구역 j는 최소한 하나의 카메라로 커버되어야 함
for j in range(num_zones):
    solver.Add(sum(x[i] for i in range(num_cameras) if j in coverage[i]) >= 1)

# 5. 목적함수: 설치하는 카메라의 수를 최소화
solver.Minimize(solver.Sum(x))

# 6. 최적화 수행 및 결과 출력
status = solver.Solve()
if status == pywraplp.Solver.OPTIMAL:
    print("최소 카메라 개수:", int(solver.Objective().Value()))
    print("선택된 카메라 위치:")
    for i in range(num_cameras):
        if x[i].solution_value() == 1:
            print(f" - 카메라 {i+1}")
else:
    print("해를 찾을 수 없습니다.")


