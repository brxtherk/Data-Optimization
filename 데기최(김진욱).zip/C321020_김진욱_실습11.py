# -*- coding: utf-8 -*-
"""
Created on Tue May 13 11:14:13 2025

@author: jinuk
"""
#%%예제1
from ortools.linear_solver import pywraplp

# 데이터 정의
warehouses = ['A', 'B', 'C', 'D', 'E']
cities = [1, 2, 3, 4, 5, 6]

costs = {
    'A': [1675, 400, 685, 1630, 1160, 2800],
    'B': [1460, 1940, 970, 100, 495, 1200],
    'C': [1925, 2400, 1425, 500, 950, 800],
    'D': [380, 1355, 543, 1045, 665, 2321],
    'E': [922, 1646, 700, 508, 311, 1797],
}

supply = {'A': 18, 'B': 24, 'C': 27, 'D': 22, 'E': 31}
fixed_cost = {'A': 7650, 'B': 3500, 'C': 3500, 'D': 4100, 'E': 2200}
demand = [10, 8, 12, 6, 7, 11]  # 각 도시의 수요

# Solver 생성
solver = pywraplp.Solver.CreateSolver('SCIP')

# 변수 정의
x = {}
for i in warehouses:
    for j in range(6):
        x[i, j] = solver.IntVar(0, solver.infinity(), f'x_{i}_{j}')

y = {i: solver.IntVar(0, 1, f'y_{i}') for i in warehouses}

# 목적함수 정의
solver.Minimize(
    sum(costs[i][j] * x[i, j] for i in warehouses for j in range(6)) +
    sum(fixed_cost[i] * y[i] for i in warehouses)
)

# 제약조건
for j in range(6):  # 도시 수요
    solver.Add(sum(x[i, j] for i in warehouses) >= demand[j])

for i in warehouses:  # 창고 용량
    solver.Add(sum(x[i, j] for j in range(6)) <= supply[i] * y[i])

# 최적화
status = solver.Solve()

# 결과 출력
if status == pywraplp.Solver.OPTIMAL:
    print(f"총 최소 비용: {solver.Objective().Value():,.2f}원\n")
    for i in warehouses:
        if y[i].solution_value() > 0:
            print(f"창고 {i} 사용 (고정비용: {fixed_cost[i]})")
            for j in range(6):
                if x[i, j].solution_value() > 0:
                    print(f" - 도시 {j+1}에 {x[i, j].solution_value()}톤 공급 (단가: {costs[i][j]})")
else:
    print("최적 해를 찾지 못했습니다.")
#%% 연습문제1
from ortools.linear_solver import pywraplp

# 데이터 정의
plants = ['P1', 'P2', 'P3', 'P4', 'P5']
warehouses = ['W1', 'W2', 'W3', 'W4', 'W5', 'W6']

# 수송비 ($1000 단위)
transport_cost = {
    'P1': [67, 98, 105, 18, 306, 140],
    'P2': [24, 60, 23, 87, 140, 140],
    'P3': [15, 34, 18, 30, 164, 164],
    'P4': [17, 35, 25, 45, 82, 82],
    'P5': [37, 47, 45, 59, 88, 88]
}

# 생산 용량 (1000대 단위)
capacity = {'P1': 12, 'P2': 18, 'P3': 10, 'P4': 15, 'P5': 31}

# 고정 운영비 ($1000 단위)
fixed_cost = {'P1': 306, 'P2': 140, 'P3': 164, 'P4': 82, 'P5': 88}

# 수요 (1000대 단위)
demand = [10, 7, 8, 6, 7, 11]

# solver 생성
solver = pywraplp.Solver.CreateSolver('SCIP')

# 변수 정의
x = {}
for p in plants:
    for j in range(6):
        x[p, j] = solver.IntVar(0, solver.infinity(), f'x_{p}_{j}')

y = {p: solver.IntVar(0, 1, f'y_{p}') for p in plants}

# 목적함수 정의: 수송비 + 고정비용
objective = solver.Sum(transport_cost[p][j] * x[p, j] for p in plants for j in range(6)) + \
            solver.Sum(fixed_cost[p] * y[p] for p in plants)
solver.Minimize(objective)

# 제약조건: 각 창고의 수요 충족
for j in range(6):
    solver.Add(solver.Sum(x[p, j] for p in plants) >= demand[j])

# 제약조건: 각 공장의 생산량은 용량 이내, 공장 열렸을 때만
for p in plants:
    solver.Add(solver.Sum(x[p, j] for j in range(6)) <= capacity[p] * y[p])

# 최적화 수행
status = solver.Solve()

# 결과 출력
if status == pywraplp.Solver.OPTIMAL:
    total_cost = solver.Objective().Value()
    used_plants = [p for p in plants if y[p].solution_value() > 0]
    
    print(f'\n총 최소 비용: ${total_cost:,.0f}K\n')
    for p in used_plants:
        print(f'공장 {p} 운영:')
        for j in range(6):
            quantity = x[p, j].solution_value()
            if quantity > 0:
                print(f'  - 창고 {j+1}에 {quantity:.1f}천대 (단가 ${transport_cost[p][j]}K)')
else:
    print("최적 해를 찾지 못했습니다.")
#%%예제문제2번

from ortools.linear_solver import pywraplp

cost = [
        [81, 92, 101, 130, 115],
        [117, 77, 108, 98, 100],
        [102, 105, 95, 119, 111],
        [115, 125, 90, 59, 74],
        [142, 100, 103, 105, 71]
]

ncost=5

s_capa = 10
l_capa = 20

d = [12, 8, 14, 16, 7]

s_cost = [6000, 4500, 6500, 4100, 4000]
l_cost = [9000, 6750, 9750, 6150, 6000]

solver = pywraplp.Solver.CreateSolver("SAT")
infinity = solver.infinity()

X = {}
for i in range(ncost):
    for j in range(ncost):
        X[i, j] = solver.IntVar(0, infinity, "X"+str(i)+str(j))
            
Y = {}
for i in range(ncost):
    Y[i] = solver.IntVar(0, 1, "Y[%i]" %i)
    
Z = {}
for i in range(ncost):
    Z[i] = solver.IntVar(0, 1, "Z[%i]" %i)
    
# 제약조건
# 수요보다 커야한다
for j in range(ncost):
    solver.Add(solver.Sum([X[i,j] for i in range(ncost)]) >= d[j])

# 설립되면 공급이 발생한다
for i in range(ncost):
    solver.Add(solver.Sum([X[i,j] for j in range(ncost)]) <= s_capa*Y[i] + l_capa*Z[i])

# Objective
objective_terms = []
for i in range(ncost):
    for j in range(ncost):
        objective_terms.append(cost[i][j] * X[i, j])
                                   
for i in range(ncost):
    objective_terms.append(s_cost[i] * Y[i])
    
for i in range(ncost):
    objective_terms.append(l_cost[i] * Z[i])

solver.Minimize(solver.Sum(objective_terms))

if 1:
    with open('or9-1.lp', "w") as out_f:
        lp_text = solver.ExportModelAsLpFormat(False)
        out_f.write(lp_text)

# Solve
status = solver.Solve()

# Print solution.
if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE: 
    print(f"Total cost = {solver.Objective().Value():.1f}\n", )
    for i in range(ncost): 
        for j in range(ncost):
            if X[i, j].solution_value() > 0.5: 
                    print(f"X[{i},{j}]")
            
    for i in range(ncost):
        print(f"{i} 저용량창고건설여부: ", Y[i].solution_value())
    for i in range(ncost):
        print(f"{i} 고용량창고건설여부: ", Z[i].solution_value())
        
else:
    print("No solution found.")
    
#%%
#연습문제 2-1

from ortools.linear_solver import pywraplp

cost = [[23,9,23,29,33],
        [19,15,21,26,36],
        [31,11,40,40,20]
        ]

s = 40000

d = [15000,20000,13000,12000,19000]

f_cost = [18000000,17500000,24500000]

nW=3
nM=5

solver = pywraplp.Solver.CreateSolver("SAT")
infinity = solver.infinity()

X = {}
for i in range(nW):
    for j in range(nM):
        X[i, j] = solver.IntVar(0, infinity, "X"+str(i)+str(j))
            
Y = {}
for i in range(nW):
    Y[i] = solver.IntVar(0, 1, "Y[%i]" %i)
    
# 제약조건
# 수요보다 커야한다
for j in range(nM):
    solver.Add(solver.Sum([X[i,j] for i in range(nW)]) >= d[j])

# 설립되면 공급이 발생한다
for i in range(nW):
    solver.Add(solver.Sum([X[i,j] for j in range(nM)]) <= s*Y[i])

# Objective
objective_terms = []
for i in range(nW):
    for j in range(nM):
        objective_terms.append(cost[i][j] * X[i, j])
                                   
for i in range(nW):
    objective_terms.append(f_cost[i] * Y[i])

solver.Minimize(solver.Sum(objective_terms))

if 1:
    with open('or9-1.lp', "w") as out_f:
        lp_text = solver.ExportModelAsLpFormat(False)
        out_f.write(lp_text)

# Solve
status = solver.Solve()

# Print solution.
if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE: 
    print(f"Total cost = {solver.Objective().Value():.1f}\n", )
    for i in range(nW): 
        for j in range(nM):
            if X[i, j].solution_value() > 0.5: 
                    print(f"X[{i},{j}]")

            
    for i in range(nW):
        print(f"{i} 창고건설여부: ", Y[i].solution_value())
else:
    print("No solution found.")
    
#%%
#예제문제 2-2

from ortools.linear_solver import pywraplp

cost = [[23,9,23,29,33],
        [19,15,21,26,36],
        [31,11,40,40,20]
        ]

s_s = 40000
s_l = 60000

d = [15000,40000,13000,12000,19000]

s_cost = [18000000,17500000,24500000]
l_cost = [23400000,22750000,31850000]

nW=3
nM=5

solver = pywraplp.Solver.CreateSolver("SAT")
infinity = solver.infinity()

X = {}
for i in range(nW):
    for j in range(nM):
        X[i, j] = solver.IntVar(0, infinity, "X"+str(i)+str(j))
            
Y = {}
for i in range(nW):
    Y[i] = solver.IntVar(0, 1, "Y[%i]" %i)
    
Z = {}
for i in range(nW):
    Z[i] = solver.IntVar(0, 1, "Z[%i]" %i)
    
# 제약조건
# 수요보다 커야한다
for j in range(nM):
    solver.Add(solver.Sum([X[i,j] for i in range(nW)]) >= d[j])

# 설립되면 공급이 발생한다
for i in range(nW):
    solver.Add(solver.Sum([X[i,j] for j in range(nM)]) <= s_s*Y[i] + s_l*Z[i])

# 저용량 OR 고용량 공장 하나만 가동해야 한다.
for i in range(nW):
    solver.Add(Y[i] + Z[i] <= 1)

# Objective
objective_terms = []
for i in range(nW):
    for j in range(nM):
        objective_terms.append(cost[i][j] * X[i, j])
                                   
for i in range(nW):
    objective_terms.append(s_cost[i] * Y[i])
    
for i in range(nW):
    objective_terms.append(l_cost[i] * Z[i])    

solver.Minimize(solver.Sum(objective_terms))

if 1:
    with open('or9-1.lp', "w") as out_f:
        lp_text = solver.ExportModelAsLpFormat(False)
        out_f.write(lp_text)

# Solve
status = solver.Solve()

# Print solution.
if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE: 
    print(f"Total cost = {solver.Objective().Value():.1f}\n", )
    for i in range(nW): 
        for j in range(nM):
            if X[i, j].solution_value() > 0.5: 
                    print(f"X[{i},{j}]")

            
    for i in range(nW):
        print(f"{i} 저용량창고건설여부: ", Y[i].solution_value())
    for i in range(nW):
        print(f"{i} 고용량창고건설여부: ", Z[i].solution_value())
        
else:
    print("No solution found.")





#%%
node_name = {0: 'O', 1: 'A', 2: 'B', 3: 'C', 4: 'D', 5: 'E', 6: 'T'}
COSTS = {(0, 1): 2, (0, 2):5, (0, 3): 4, (1, 2): 2, (1, 4): 7,
(2, 3): 1, (2, 4): 4, (2, 5): 3, (3, 2): 1, (3, 5): 4,
(4, 5): 1, (4, 6): 5, (5, 4): 1, (5, 6): 7}
FLOW = [1, 0, 0, 0, 0, 0, -1]
nNodes = len(FLOW)
X = {}
for key in COSTS.keys():
    X[key] = solver.IntVar(0, 1, "X[%i,%i]" %(key[0], key[1]))
# 제약조건
for i in range(nNodes):
    const_expr = []
    for key in COSTS.keys():
        if key[0] == i: # incoming traffic
            const_expr.append(X[key]) 
        elif key[1] == i: # outgoing traffic
            const_expr.append(-X[key[0], key[1]])
    solver.Add(solver.Sum(const_expr) == FLOW[i], 'node_'+str(i))

# 목적함수
objective_terms = [] 
for key, value in COSTS.items():
    objective_terms.append(value * X[key])

solver.Minimize(solver.Sum(objective_terms))

if 1:
    with open('or11-ex3.lp', "w") as out_f:
        lp_text = solver.ExportModelAsLpFormat(False) 
        out_f.write(lp_text)

#문제 풀이
status = solver.Solve() 

#결과 출력
if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE: 
    print(f"Total cost = {solver.Objective().Value():.1f}\n", )
    for key in COSTS.keys(): 
        if X[key].solution_value() > 0.5: 
            print(f"X{key}")
else:
    print("No solution found.")
#%%
node_name = {0: 'O', 1: 'A', 2: 'B', 3: 'C', 4: 'D', 5: 'E', 6:'F', 7:'G',8:'H',9:'i', 10: 'T'}
COSTS = {(0, 1): 4, (0, 2):3, (0, 3): 6, (1, 3): 5, (1,4):3,(2, 3): 4,
(2, 5): 6, (3,4): 2, (3, 6): 2, (3, 5): 5, (4, 7): 4,
(4, 6): 2, (5,6):1,(5,8):2,(5,9):5,(6,7):2,(6,8):5,(7,10):7,(8,7):2,(8,10):8,(9,8):3,(9,10):4}
FLOW=[1,0,0,0,0,0,0,0,0,0,-1]
nNodes = len(FLOW)
X = {}
for key in COSTS.keys():
    X[key] = solver.IntVar(0, 1, "X[%i,%i]" %(key[0], key[1]))
for i in range(nNodes):
    const_expr = []
    for key in COSTS.keys():
        if key[0] == i: # incoming traffic
            const_expr.append(X[key])
        elif key[1] == i: # outgoing traffic
            const_expr.append(-X[key[0], key[1]])
    solver.Add(solver.Sum(const_expr) == FLOW[i], 'node_'+str(i))

# 목적함수
objective_terms = [] 
for key, value in COSTS.items():
    objective_terms.append(value * X[key])

solver.Minimize(solver.Sum(objective_terms))

if 1:
    with open('or11-ex3.lp', "w") as out_f:
        lp_text = solver.ExportModelAsLpFormat(False) 
        out_f.write(lp_text)

#문제 풀이
status = solver.Solve() 

#결과 출력
if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE: 
    print(f"Total cost = {solver.Objective().Value():.1f}\n", )
    for key in COSTS.keys(): 
        if X[key].solution_value() > 0.5: 
            print(f"X{key}")
else:
    print("No solution found.")