# -*- coding: utf-8 -*-
"""
Created on Tue Mar 18 09:47:40 2025

@author: jinuk
"""

#%% 문제1-solution1
# 의사결정 변수 사우디산 원유량=x 베네수엘라산 원유량=y
# 목적함수 60*x +55*y 를 최소화
# 제약조건 x<=9000, y<=6000
#가솔린 0.3*x+0.4*y>=2000
#제트유 0.4*x+0.2*y>=1500
#윤활유 0.2*x+0.3*y>=500
# x,y>=0

from ortools.linear_solver import pywraplp

solver=pywraplp.Solver.CreateSolver('SCIP')

#의사결정변수
x=solver.NumVar(0,solver.infinity(),'x')
y=solver.NumVar(0,solver.infinity(),'y')

#제약조건
solver.Add(x<=9000)
solver.Add(y<=6000)
solver.Add(0.3*x+0.4*y>=2000)
solver.Add(0.4*x+0.2*y>=1500)
solver.Add(0.2*x+0.3*y>=500)

#목적함수
solver.Minimize(60*x +55*y)

status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print(f'최적의 가격: {solver.Objective().Value():0.1f}')
    print(f'구입 할 사우디산 원유량 {x.solution_value():.1f}')
    print(f'구입 할 베네수엘라산 원유량 {y.solution_value():.1f}')
else:
    print('최적값을 찾지 못했습니다')
#%% 문제1-solution2

from ortools.linear_solver  import pywraplp

solver=pywraplp.Solver.CreateSolver('SCIP')

data={}
data['제약조건계수']=[[0.3,0.4],[0.4,0.2],[0.2,0.3],[-1,0],[0,-1]]
data['제약조건개수']=5
data['범위']=[2000,1500,500,-9000,-6000]
data['변수개수']=2
data['목적함수계수']=[60,55]

#의사결정변수 만들기
x={}

for i in range(data['변수개수']):
    x[i]=solver.NumVar(0,solver.infinity(),'x[%i]'%i)

#제약조건
for i in range(data['제약조건개수']):
    a=[data['제약조건계수'][i][j]*x[j] for j in range(data['변수개수'])]
    solver.Add(sum(a)>=data['범위'][i])
    
#목적함수
solver.Minimize(solver.Sum([data['목적함수계수'][i]*x[i] for i in range(data['변수개수'])]))

status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print(f'최적의 가격: {solver.Objective().Value():0.1f}')
    print(f'구입 할 사우디산 원유량 {x[0].solution_value():.1f}')
    print(f'구입 할 베네수엘라산 원유량 {x[1].solution_value():.1f}')
else:
    print('최적값을 찾지 못했습니다')
    

#%% 문제2_solution1

#의사결정변수: 원석1의 구입량=x, 원석2의 구입량=y (단위:톤)
#목적함수: 10*x+15*y 의 최소화
#제약조건: x,y>0
#가돌리늄 (0.2*x+0.3*y)/100>=8
#홀륨 (0.15*x+0.25*y)/100>=6
#툴륨 (0.2*x+0.1*y)/100>=4

from ortools.linear_solver import pywraplp

solver=pywraplp.Solver.CreateSolver('SCIP')

#의사결정변수
x=solver.NumVar(0,solver.infinity(),'x')
y=solver.NumVar(0,solver.infinity(),'y') 
#제약조건
solver.Add((0.002*x+0.003*y)>=8) #퍼센트
solver.Add((0.0015*x+0.0025*y)>=6)
solver.Add((0.002*x+0.001*y)>=4)


#목적함수
solver.Minimize(10*x+15*y)

status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print(f'원석 구입 최소 가격: {solver.Objective().Value():0.1f}만원')
    print(f'원석1 구입량 {x.solution_value():0.1f}톤')
    print(f'원석2 구입량 {abs(y.solution_value()):0.1f}톤')
else:
    print('최적값을 찾지 못했습니다.')
#%% 문제2_solution2

from ortools.linear_solver import pywraplp

solver=pywraplp.Solver.CreateSolver('SCIP')

data={}
data['constraint_coeffs']=[[0.2,0.3],[0.15,0.25],[0.2,0.1]]
data['obj_coeffs']=[10,15]
data['bounds']=[800,600,400]
data['num_constraints']=3
data['num_vars']=2

#의사결정변수
x=[solver.NumVar(0,solver.infinity(),'x[%i]'%i)for i in range(data['num_vars'])]

#제약조건
for i in range(data['num_constraints']):
    a=[data['constraint_coeffs'][i][j]*x[j] for j in range(data['num_vars'])]
    solver.Add(sum(a)>=data['bounds'][i])

#목적함수
solver.Minimize(solver.Sum([data['obj_coeffs'][i]*x[i] for i in range(data['num_vars'])]))

status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print('원석최소구입가격',round(solver.Objective().Value(),2))
    for i in range(data['num_vars']):
        print(x[i].name(),':',round(x[i].solution_value(),2))
        
#%%문제3_solution 1
#의사결정변수: 유모차 생산량=x, 보행기 생산량=y, 자전거 생산량=z
#목적함수: 유모차,보행기,자전거의 수익과 임대이익((기계의 활용가능시간-작동된 시간)*임대료)을 더했다
# 30*x + 20*y + 16*z + 3.5*(240-(8*x+3*y+3*z))+3*(100-(4*x+2*z)) 를 최대

#제약조건 x,y,z>=0
#기계1 8*x+ 3*y +3*z <=240 
#기계2 4*x +4*y<=200
#기계3 4*x +2*z<=100

from ortools.linear_solver import pywraplp

solver=pywraplp.Solver.CreateSolver('SCIP')

#의사결정변수
x=solver.IntVar(0,solver.infinity(),'x')
y=solver.IntVar(0,solver.infinity(),'y')
z=solver.IntVar(0,solver.infinity(),'z')

solver.Add(8*x+ 3*y +3*z <=240)
solver.Add(4*x +4*y<=200)
solver.Add(4*x +2*z<=100)

solver.Maximize(30*x+20*y+16*z+3.5*(240-(8*x+3*y+3*z))+3*(100-(4*x+2*z)))

status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    a=(240 - (8*x.solution_value() + 3*y.solution_value() + 3*z.solution_value()))
    b=(100 - (4*x.solution_value() + 2*z.solution_value()))
    print(f'최대 총 수익: {solver.Objective().Value():0.2f}만원')
    판매수익 = solver.Objective().Value() - (3.5 * a + 3 * b)
    print('판매 수익', 판매수익, '만원')
    print(f'유모차 생산량: {x.solution_value()}')
    print(f'보행기 생산량: {y.solution_value()}')
    print(f'자전거 생산량: {z.solution_value()}')
    print('기계1 임대가능시간: ',a,'시간')
    print('기계2 임대가능시간',b,'시간')
    print('임대 수익 ', 3.5 * a + 3 * b, '만원')

else:
    print('최적값을 찾지 못했습니다.')
#%%문제3_solution 2

from ortools.linear_solver import pywraplp

solver=pywraplp.Solver.CreateSolver('SCIP')

data={}
data['constrain_coeffs']=[[8,3,3],[4,4,0],[4,0,2]]
data['bounds']=[240,200,100]
data['num_constraints']=3
data['num_vars']=3

#의사결정변수
x=[solver.IntVar(0,solver.infinity(),'x[%i]'%i)for i in range(data['num_vars'])]

#제약조건
for i in range(data['num_constraints']):
    a=[data['constrain_coeffs'][i][j]*x[j]for j in range(data['num_vars'])]
    solver.Add(sum(a)<=data['bounds'][i])
    
#목적함수
solver.Maximize(-10 * x[0] + 9.5 * x[1] - 0.5 * x[2] + 1140)

status=solver.Solve()
if status==pywraplp.Solver.OPTIMAL:
    a=(240 - (8*x[0].solution_value() + 3*x[1].solution_value() + 3*x[2].solution_value()))
    b=(100 - (4*x[0].solution_value() + 2*x[2].solution_value()))
    print(f'최대 총 수익: {solver.Objective().Value():0.2f}만원')
    판매수익 = solver.Objective().Value() - (3.5 * a + 3 * b)
    print('판매 수익', 판매수익, '만원')
    print(f'유모차 생산량: {x[0].solution_value()}')
    print(f'보행기 생산량: {x[1].solution_value()}')
    print(f'자전거 생산량: {x[2].solution_value()}')
    print('기계1 임대가능시간: ',a,'시간')
    print('기계2 임대가능시간',b,'시간')
    print('임대 수익 ', 3.5 * a + 3 * b, '만원')

else:
    print('최적값을 찾지 못했습니다.')
