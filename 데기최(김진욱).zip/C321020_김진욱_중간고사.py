# -*- coding: utf-8 -*-
"""
Created on Tue Apr 22 09:50:58 2025

@author: Administrator
"""

from ortools.linear_solver import pywraplp

solver=pywraplp.Solver.CreateSolver('SCIP')
#%%문제 1
from ortools.linear_solver import pywraplp

solver=pywraplp.Solver.CreateSolver('SCIP')

infinity=solver.infinity()

a=[4,8,10,6]
x={}
for i in range(4):
    x[i]=solver.IntVar(0,infinity,f'x{i}')
y={}
for i in range(2):
    y[i]=solver.IntVar(0,infinity,f'x{i}')

solver.Add(x[0]+y[0]>=a[0])
solver.Add(x[1]+y[0]>=a[1])
solver.Add(x[2]+y[1]>=a[2])
solver.Add(x[3]+y[1]>=a[3])
for i in range(2):
    solver.Add(y[i]>=2)
solver.Minimize(sum(13000*x[i]+30000*y[j] for i in range(4) for j in range(2)))
objective=solver.Objective()

status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print(f'총돈={objective.Value()}')
    for i in range(4):
        print(f'{x[i].solution_value()}')
    for j in range(2):
        print(f'{y[j].solution_value()}')
    
#%%문제 2
from ortools.linear_solver import pywraplp

solver=pywraplp.Solver.CreateSolver('SCIP')

infinity=solver.infinity()
M=1000000

time=[[3,4,2],[4,6,2]]
profit=[500,700,300]
need=[7,5,9]
limit=[30,40]

x={}

for i in range(2):
    for j in range(3):
        x[i,j]=solver.IntVar(0,infinity,f'{i+1}공장에서 {j+1}제품')

y=solver.IntVar(0,1,'공장 선택')

solver.Add(sum(x[0,j] for j in range(3))<=M*y)
solver.Add(sum(x[1,j] for j in range(3))<=M*(1-y))

for i in range(2):
    solver.Add(sum(time[i][j]*x[i,j] for j in range(3))<=limit[i])
    
for j in range(3):
    solver.Add(sum(x[i,j] for i in range(2))<=need[j])
    
objective=solver.Objective()

solver.Maximize(sum(profit[j]*x[i,j] for i in range(2) for j in range(3)))
status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print(f'총이익={objective.Value()}')
    for i in range(2):
        for j in range(3):
            if x[i,j].solution_value()>0:
                print(f'{x[i,j].name()}={x[i,j].solution_value()}')
#%%문제3
from ortools.linear_solver import pywraplp

solver=pywraplp.Solver.CreateSolver('SCIP')

infinity=solver.infinity()

a=[[1,0,0,0,1,0,0,0,1,0],
   [0,1,0,1,0,1,0,0,1,1],
   [0,0,1,1,0,0,1,0,1,0],
   [1,0,0,0,0,1,0,1,0,0],
   [0,0,1,1,0,1,0,0,0,0],
   [0,1,0,0,1,0,0,0,0,0],
   [1,0,0,0,0,0,1,1,0,1],
   [0,0,1,0,1,0,0,0,0,1],
   [0,1,0,1,0,0,1,0,0,0]]
b=[6,4,7,5,4,6,5,3,7,6]
M=1000000
x={}
for i in range(9):
    for j in range(10):
        x[i,j]=solver.IntVar(0,1,f'x{i}{j}')
y={}
for j in range(10):
    y[j]=solver.IntVar(0,1,f'{j+1}경로선택')

for i in range(9):
    solver.Add(sum(a[i][j]*x[i,j] for j in range(10))>=1)


for j in range(10):
    solver.Add(sum(x[i,j] for i in range(9))<=M*y[j])


solver.Add(sum(y[j] for j in range(10))<=3)

for i in range(9):
    solver.Add(sum(a[i][j]*x[i,j] for j in range(10))>=1)

objective=solver.Objective()

solver.Minimize(sum(y[j]*b[j] for j in range(10)))

status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print(f'총시간={objective.Value()}')
    for j in range(10):
        if y[j].solution_value()>0:
            print(f'{y[j].name()}')
#%% 문제4
#%% 문제5
from ortools.linear_solver import pywraplp

solver=pywraplp.Solver.CreateSolver('SCIP')

infinity=solver.infinity()
M=1000000

need=[2,2,2,4,2,1,1,4,1]
weight=[2,3,1.5,1,4]
cost=[24,20,36,28,39]

a=[[0.002,0.01,M,0.01,0.007],
   [M,0.01,0.002,M,0.004],
   [M,M,M,0.007,M],
   [0.003,M,M,0.006,0.008],
   [M,M,0.004,0.001,M],
   [M,0.006,0.001,M,M],
   [0.002,M,M,0.003,0.009],
   [0.004,0.008,0.005,M,M],
   [0.003,M,0.003,0.002,M]
   ]
b=['헤드램프','라디에이터 팬','와이퍼','좌석','사이드미러','히터팬','썬루프','유리창','안테나']
c=['A','B','C','D','E']

for i in range(9):
    for j in range(5):
        x[i,j]=solver.IntVar(0,infinity,f'{b[i]}={c[j]}')
y={}
for j in range(5):
    y[j]=solver.IntVar(0,1,f'{j+1}모터')

for i in range(9):
    solver.Add(sum(x[i,j] for j in range(5))>=need[i])

for j in range(5):
    solver.Add(sum(x[i,j] for i in range(9))<=M*y[j])

solver.Add(sum(y[j] for j in range(5))<=3)

solver.Add(sum(weight[j]*x[i,j] for i in range(9) for j in range(5))<=36)

solver.Add(sum(cost[j]*x[i,j] for i in range(9) for j in range(5))<=585)

solver.Minimize(sum(a[i][j]*x[i,j] for i in range(9) for j in range(5)))

objective=solver.Objective()
status=solver.Solve()

if status==pywraplp.Solver.OPTIMAL:
    print(f'고장날확률={objective.Value()}')
    for i in range(9):
        for j in range(5):
            if x[i,j].solution_value()>0:
                print(f'{x[i,j].name()}, :{x[i,j].solution_value()}개 사용')
