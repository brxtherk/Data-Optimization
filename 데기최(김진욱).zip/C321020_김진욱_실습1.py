# -*- coding: utf-8 -*-
"""
Created on Tue Mar  5 11:41:52 2024

@author: hiie18
"""

#%% 실습1
from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver("SCIP")
# 의사결정변수
x = solver.IntVar(0, solver.infinity(), "x")
y = solver.IntVar(0, solver.infinity(), "y")
# 제약조건
solver.Add(x + 2 * y <= 13.0)
solver.Add( 3 * x - y >= 0.0)
solver.Add(x - y <= 2.0)
# 목적함수
solver.Maximize(3 * x + 1* y)
status = solver.Solve()
if status == pywraplp.Solver.OPTIMAL:
    print("OPTIMAL")
    print("목적함수값 = ", solver.Objective().Value())
    print('x = %.1f' %(x.solution_value()))
    print('y = %.1f' %(y.solution_value()))
else:
    print("The problem does not have an optimal solution.")
 
#%% 실습2
from ortools.linear_solver import pywraplp
solver = pywraplp.Solver.CreateSolver("SCIP")
# 새로운 정수 변수 z를 선언 (x를 2의 배수로 만들기 위해 사용)
z = solver.IntVar(0, solver.infinity(), "z")
x = solver.IntVar(0, solver.infinity(), "x")
solver.Add(x == 2 * z)  # x가 항상 2의 배수
y = solver.IntVar(0, solver.infinity(), "y")

# 제약 조건
solver.Add(x + 2 * y <= 13.0)
solver.Add(3 * x - y >= 0.0)
solver.Add(x - y <= 2.0)

# 목적 함수
solver.Maximize(3 * x + 1 * y)

# 문제 해결
status = solver.Solve()

# 결과 출력
if status == pywraplp.Solver.OPTIMAL:
    print("OPTIMAL")
    print("목적함수값 = ", solver.Objective().Value())
    print('x = %.1f' % (x.solution_value()))  # 항상 짝수
    print('y = %.1f' % (y.solution_value()))
else:
    print("The problem does not have an optimal solution.")

#%% 실습3

from ortools.linear_solver import pywraplp
data = {}
data["constraint_coeffs"] = [
        [5, 7, 9, 2, 1],
        [18, 4, -9, 10, 12],
        [4, 7, 3, 8, 5],
        [5, 13, 16, 3, -7],
]
data["bounds"] = [250, 285, 211, 315]
data["obj_coeffs"] = [7, 8, 2, 9, 6]
data["num_vars"] = 5
data["num_constraints"] = 4  
# Create the mip solver with the SCIP backend.
solver = pywraplp.Solver.CreateSolver("SCIP")
infinity = solver.infinity()
x = {}
for j in range(data["num_vars"]):
    x[j] = solver.IntVar(0, infinity, "x[%i]" % j)
    # 제약조건
for i in range(data['num_constraints']):
    constraint_expr = [data['constraint_coeffs'][i][j] * x[j] for j in range(data['num_vars'])]
    solver.Add(sum(constraint_expr) <= data['bounds'][i])
# 목적함수
objective = solver.Objective()
obj_expr = [data['obj_coeffs'][j] * x[j] for j in range(data['num_vars'])]
solver.Maximize(solver.Sum(obj_expr))
# 문제 풀이 시작

status = solver.Solve()
#결과 출력
if status == pywraplp.Solver.OPTIMAL:
    print("Objective value =", solver.Objective().Value())
    for j in range(data["num_vars"]):
        print(x[j].name(), " = ", x[j].solution_value())
else:
    print("The problem does not have an optimal solution.")